# Torque Lab

Torque Lab is a beginner-friendly car discovery and buying-advice website, in the spirit of CarDekho and CarWale.
Answer a few questions about your budget, family, daily drive and preferences, and it recommends cars, explains
**why** each one fits, and is upfront about the trade-offs. It also tells you whether a hatchback, sedan, SUV or MUV
suits you best, and which fuel (petrol, diesel, CNG, hybrid or electric) makes financial sense.

**Stack:** React 18 + Vite (frontend), Node.js + Express 5 (API), MySQL 8 via `mysql2` (database).

## Deploy with one command (Docker)

1. Put your MySQL connection details in `.env` (copy `.env.example`). This project uses an **Aiven** MySQL
   database: set `DATABASE_HOST`, `DATABASE_PORT`, `DATABASE_NAME`, `DATABASE_USER`, `DATABASE_PASSWORD` and
   `DATABASE_SSL=true`, or paste Aiven's Service URI as `DATABASE_URL`.
2. Run:

   ```bash
   docker compose up -d --build
   ```

Open **http://localhost:4000** (or the `PORT` from `.env`). On start, the app:

- connects to your database;
- creates any missing tables;
- loads the sample data if the catalogue is empty: 78 cars, 15 brands and a demo account.

Existing data is never overwritten. The container restarts automatically if it crashes or the machine reboots.

| Task                                         | Command                                     |
| -------------------------------------------- | ------------------------------------------- |
| See logs                                     | `docker compose logs -f app`                |
| Stop                                         | `docker compose down`                       |
| Update after changing code                   | `docker compose up -d --build`              |
| Reload the car catalogue from `server/data/` | `docker compose exec app npm run db:reset`  |

**Demo account:** `demo@torquelab.dev` / `DemoPass123`. It comes with saved cars and Car Finder answers. Set
`SEED_DEMO_DATA=false` in `.env` before first start if you don't want it on a public deployment.

## Run locally with npm (for development)

**Prerequisites:** Node.js **20 or newer** (22 recommended; there is an `.nvmrc`, so `nvm use` works), and the same
`.env` as above.

```bash
npm install
npm run dev
```

Open **http://localhost:5173**. The API runs on port 4000 (`PORT`) and restarts when server files change. Vite serves
the React app with hot reload and forwards `/api` requests to the API. To run it the way it runs in production:
`npm run build && npm start`, then open http://localhost:4000.

## Configuration

All settings are environment variables, usually kept in `.env` (see `.env.example`).

| Variable            | Default            | Purpose                                                                                       |
| ------------------- | ------------------ | --------------------------------------------------------------------------------------------- |
| `DATABASE_URL`      | –                  | Full connection URI, e.g. Aiven's **Service URI**: `mysql://user:pass@host:port/db?ssl-mode=REQUIRED`. Overrides the variables below. |
| `DATABASE_HOST`     | `localhost`        | MySQL host                                                                                     |
| `DATABASE_PORT`     | `3306`             | MySQL port. Cloud providers such as Aiven use a custom port.                                   |
| `DATABASE_NAME`     | `torque_lab`       | Database name (Aiven's default is `defaultdb`)                                                 |
| `DATABASE_USER`     | `root`             | MySQL user                                                                                     |
| `DATABASE_PASSWORD` | –                  | MySQL password                                                                                 |
| `DATABASE_SSL`      | `false`            | Use an encrypted connection. **Required for Aiven** and most cloud databases.                  |
| `DATABASE_SSL_CA`   | –                  | Optional path to the server's CA certificate (Aiven: download `ca.pem`) to also verify it. With Docker, the file must be available inside the container, e.g. via a volume. |
| `PORT`              | `4000`             | Port the site is served on (with Docker: the port on your machine)                             |
| `JWT_SECRET`        | generated          | Secret that signs login tokens. If empty, one is generated once and stored in the database.    |
| `COOKIE_SECURE`     | `false`            | Set to `true` when serving over HTTPS                                                          |
| `SEED_DEMO_DATA`    | `true`             | Create the demo account on first start                                                         |

### Connecting to Aiven

1. In the Aiven console, make sure the MySQL service is **Running** (free-tier services power off when idle).
2. Copy the **Service URI** from the service overview page and set it as `DATABASE_URL` in `.env`. Alternatively,
   copy the host, **port**, user, password and database into the `DATABASE_*` variables and set `DATABASE_SSL=true`.
3. Start the app. If the connection fails, the log says why: host not found, wrong port or firewall (timeout),
   wrong password, or missing SSL.

## Database

Tables are created automatically from [`server/db/schema.sql`](server/db/schema.sql) whenever the server starts. Every
statement is `CREATE TABLE IF NOT EXISTS`, so restarting is safe. When the `cars` table is empty, the catalogue is
loaded from [`server/data/`](server/data).

| Table               | Contents                                                                    |
| ------------------- | --------------------------------------------------------------------------- |
| `brands`            | 15 brands with country and their name in the NHTSA vehicle database         |
| `cars`              | 78 models: price range, body type, seats, dimensions, safety, ratings       |
| `car_engines`       | Engine and electric-motor options (displacement, power, torque, battery)    |
| `car_fuel_options`  | Each fuel a car offers, with starting price and claimed efficiency          |
| `car_transmissions` | Gearboxes offered                                                           |
| `car_highlights`    | Pros and cons                                                               |
| `users`             | Accounts (bcrypt-hashed passwords)                                          |
| `user_preferences`  | Each user's last Car Finder answers                                         |
| `shortlists`        | Cars saved to "My Garage"                                                   |
| `api_cache`         | Cached responses from the live NHTSA API                                    |
| `app_settings`      | Generated secrets (the JWT secret when none is configured)                  |
| `client_errors`     | Problems reported by visitors' browsers (see below); kept for 30 days       |

To change the catalogue, edit [`server/data/cars.js`](server/data/cars.js) and
[`server/data/brands.js`](server/data/brands.js), then run `npm run db:reset`. That reloads the cars and keeps user
accounts, but clears users' saved cars, because car ids change.

## Features

- **Car Finder**: a 5-step questionnaire covering budget, people, daily distance, roads, mileage target, fuel, gearbox,
  body type and priorities. Results include:
  - the body type that suits you best, with reasons;
  - which fuel pays off at your daily distance, with cost per km, monthly cost, payback time and 5-year savings;
  - ranked cars with a match score, reasons, trade-offs, a suggested fuel and gearbox, a monthly fuel bill and the
    full score breakdown.
- **78 cars from 15 brands**: Maruti Suzuki, Hyundai, Tata, Mahindra, Toyota, Kia, Honda, Volkswagen, Skoda, MG,
  Renault, Nissan, Citroen, Jeep and BYD. They include **8 electric cars**, with range, battery and charging costs
  handled throughout.
- **Live global data**: each car page shows the brand's current US line-up from the free
  [NHTSA vPIC API](https://vpic.nhtsa.dot.gov/api/), and whether that model is sold there too. Responses are
  cached in MySQL for a week, and the last saved copy is served if NHTSA is unreachable. No API key is needed.
- **Browse**: filter by budget, brand, body type, fuel, gearbox and seats. Filters live in the URL, so they can be
  shared.
- **Car details**: specs, engine/motor options, fuel options with starting prices, pros/cons, ratings and similar
  cars.
- **Compare** 2–3 cars side by side, with the best value in each row highlighted. The comparison URL can be shared.
- **Accounts**: sign up and log in (JWT in an httpOnly cookie), save cars to My Garage, and have Car Finder answers
  remembered.

## How recommendations work

All logic is plain, rule-based JavaScript in [`server/lib/recommend.js`](server/lib/recommend.js), with no AI APIs:

1. **Validate the answers**, filling in sensible defaults.
2. **Advise a body type.** Each type starts at 50 points. Rules then add or subtract points with a reason, for example
   "+30 SUV: high ground clearance" for rough roads, or "−60 hatchback: only 5 seats" for a family of seven.
3. **Advise a fuel.**
   - Under 30 km a day: petrol.
   - 80 km a day or more on highways or rough roads: diesel.
   - Otherwise: the fuel with the biggest **5-year saving** over petrol (fuel saved minus its extra purchase price)
     that is available at your budget. EVs are not suggested for rough roads.
4. **Apply must-haves.** Cars must start within 5% of your budget, have enough seats, and match any fuel, gearbox or
   body type you explicitly chose. If fewer than 3 cars pass, the closest near-misses are shown with what they miss.
5. **Score each remaining car from 0 to 100** as a weighted average of the factors below. Each factor writes a reason
   when it helps the car and a trade-off when it hurts it.

| Factor              | Weight                                                  | What it looks at                                              |
| ------------------- | ------------------------------------------------------- | ------------------------------------------------------------- |
| Budget fit          | 22                                                      | How much of the price range fits, without being far under      |
| Seats & space       | 14 (+8 if "space" is a priority)                        | Seats vs. family size, rear-seat room, boot                    |
| Claimed mileage     | 10 with a mileage target, 6 without                     | Mileage of the suggested fuel vs. your target (EVs always pass) |
| Running cost        | 4 / 8 / 14 / 18 as daily distance rises                 | ₹ per km and per month on the suggested fuel or electricity    |
| Suits your roads    | 14                                                      | City: length and automatic. Highway: power and stability. Rough: ground clearance |
| Safety              | 10 (+10 if a priority, +4 for families of 3+)           | Crash-test stars, airbags                                      |
| Body type           | 14 (4 if you picked one yourself)                       | Score from step 2                                              |
| New-driver friendly | 8 (new drivers only)                                    | Automatic option, compact size                                 |
| Performance / Comfort / Low maintenance | 10 each, when chosen as priorities  | Power and torque / comfort rating / ownership rating           |

Energy prices are set at the top of `recommend.js`: petrol ₹103/L, diesel ₹90/L, CNG ₹85/kg and home charging
₹8/kWh.

## API

| Method & path                          | Auth     | Description                                                       |
| -------------------------------------- | -------- | ----------------------------------------------------------------- |
| `GET /api/health`                      | –        | App and database status                                           |
| `GET /api/cars`                        | –        | List cars. Query: `q`, `brand`, `body`, `fuel` (comma lists), `transmission`, `maxPrice`, `minSeats`, `slugs`, `sort` |
| `GET /api/cars/meta`                   | –        | Brands, body types and fuels with counts                          |
| `GET /api/cars/:slug`                  | –        | One car plus 3 similar cars                                       |
| `GET /api/cars/:slug/global`           | –        | Live US line-up for the car's brand (NHTSA), cached               |
| `POST /api/recommendations`            | optional | Body `{ answers }`; saves the answers when logged in              |
| `POST /api/auth/signup` · `/login` · `/logout` | –  | Accounts                                                          |
| `GET /api/auth/me`                     | –        | Current user, or `null`                                           |
| `GET /api/me/shortlist`                | required | Saved cars                                                        |
| `PUT / DELETE /api/me/shortlist/:slug` | required | Save / un-save a car                                              |
| `GET /api/me/preferences`              | required | Last Car Finder answers                                           |

## Project structure

```
├── client/                   React app (Vite root)
│   └── src/
│       ├── pages/            Home, Browse, Car detail, Car Finder, Compare, Login/Signup, Garage
│       ├── components/       Car card, car illustration, navbar, compare tray, finder results…
│       ├── context/          Auth (user + saved cars) and Compare (selected cars) state
│       ├── api.js            fetch wrapper + useApi hook
│       └── styles.css        All styling (design tokens at the top)
├── server/
│   ├── index.js              Starts the server (connects to MySQL first)
│   ├── app.js                Express app: routes, static files, error handling
│   ├── config.js             Environment variables
│   ├── reset-db.js           `npm run db:reset`
│   ├── db/
│   │   ├── schema.sql        All tables
│   │   ├── index.js          Connection (with retries and clear errors), schema, first-run setup
│   │   └── seed.js           Loads the catalogue and the demo account
│   ├── data/                 Sample brands and cars (edit these to change the catalogue)
│   ├── lib/
│   │   ├── cars.js           Loads cars from MySQL, browse filters
│   │   ├── recommend.js      The recommendation engine
│   │   └── nhtsa.js          Live NHTSA vPIC client with MySQL caching
│   ├── middleware/auth.js    JWT cookie helpers
│   └── routes/               auth, cars, me (garage), recommendations
├── Dockerfile
├── docker-compose.yml        One-command deploy (uses the database in .env)
└── .env.example
```

## About the data

The cars in `server/data/cars.js` use realistic but **indicative** figures for the Indian market:

- ex-showroom prices in ₹ lakh;
- claimed mileage (ARAI) or claimed range for EVs;
- Global, Bharat or Euro NCAP ratings where one exists.

Comfort and ownership scores are Torque Lab's own 1–5 ratings. This is sample data for demonstration, so always confirm
with a dealer. The NHTSA data is official, but it covers the US market.

## Troubleshooting

- **`Could not connect to MySQL…`**: the line after it says why.
  - *Host not found*: check `DATABASE_HOST`, and that the cloud service is running.
  - *Timed out*: usually a wrong `DATABASE_PORT` or an IP allow-list.
  - *Rejected the login*: check the user and password.
  - *Does not support SSL*: set `DATABASE_SSL=false`.
- **"Live data is unavailable" on car pages**: the server couldn't reach `vpic.nhtsa.dot.gov`. The rest of the site
  is unaffected.
- **The page says "Cannot reach the server"**: the API isn't running. Use `npm run dev`, which starts both the API
  and the frontend.
- **Something fails on a visitor's device but not yours**: browsers report problems to the `client_errors` table
  and the server log. Reports include a page that never appeared within 10 s (with which JS and CSS files loaded and
  how long they took), a JavaScript crash, and API requests that failed or took over 8 s. Check them with
  `docker compose logs app | grep client-error`, or query `SELECT * FROM client_errors ORDER BY id DESC`. Slow or
  failed API requests on the server are logged as `[api] ...`, and crashes as `[process] ...`.
- **A page is blank until you refresh** (after a redeploy, on devices that visited before): this was caused by the
  server answering requests for old JS files with the HTML page. It now returns a proper 404 for missing files, and
  the page reloads itself once if its JS or CSS fails to load. Make sure the server runs the current build
  (`docker compose up -d --build`).
- **Port already in use**: change `PORT` in `.env`, or stop whatever is using it. For example, `npm run dev` and
  the Docker container both use port 4000 by default, so don't run both at once.
