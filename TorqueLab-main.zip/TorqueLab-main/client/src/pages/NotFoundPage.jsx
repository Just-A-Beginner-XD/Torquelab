import { Link } from 'react-router-dom';
import CarArt from '../components/CarArt.jsx';

export default function NotFoundPage() {
  return (
    <div className="container page not-found">
      <CarArt bodyType="hatchback" color="#9aa3b2" />
      <h1>Wrong turn</h1>
      <p className="muted">We couldn’t find that page.</p>
      <div className="hero__cta">
        <Link to="/" className="btn btn--primary">Go home</Link>
        <Link to="/cars" className="btn btn--outline">Browse cars</Link>
      </div>
    </div>
  );
}
