import { Link, useNavigate } from 'react-router-dom';
import { useApi } from '../api.js';
import { useAuth } from '../context/AuthContext.jsx';
import { useCompare } from '../context/CompareContext.jsx';
import CarCard from '../components/CarCard.jsx';
import { ArrowRightIcon, CompareIcon } from '../components/Icons.jsx';
import { EmptyState, ErrorState, Loading } from '../components/States.jsx';
import { describeAnswers } from '../finderOptions.js';

export default function GaragePage() {
  const { user, shortlist, shortlistReady } = useAuth();
  const { replace } = useCompare();
  const navigate = useNavigate();
  const saved = useApi('/me/shortlist');
  const prefs = useApi('/me/preferences');

  // Hide cars un-saved on this page straight away, without refetching.
  const cars = (saved.data?.cars || []).filter((c) => shortlist.has(c.slug));
  const compareSaved = () => {
    const top = cars.slice(0, 3);
    replace(top);
    navigate(`/compare?cars=${top.map((c) => c.slug).join(',')}`);
  };

  return (
    <div className="container page">
      <header className="page-head">
        <div>
          <p className="eyebrow">My Garage</p>
          <h1>Hi, {user.name.split(' ')[0]}</h1>
          <p className="muted">Your saved cars and Car Finder answers, all in one place.</p>
        </div>
      </header>

      <section className="panel garage-finder">
        <div>
          <h2>Your Car Finder answers</h2>
          {prefs.loading && <Loading />}
          {prefs.error && <ErrorState error={prefs.error} onRetry={prefs.reload} />}
          {prefs.data?.preferences ? (
            <div className="chip-set">
              {describeAnswers(prefs.data.preferences).map((c) => (
                <span key={c} className="chip">{c}</span>
              ))}
            </div>
          ) : (
            !prefs.loading && <p className="muted">You haven’t run the Car Finder yet. It takes about a minute.</p>
          )}
        </div>
        <div className="garage-finder__actions">
          {prefs.data?.preferences ? (
            <>
              <Link to="/finder?run=saved" className="btn btn--primary">
                See my matches <ArrowRightIcon />
              </Link>
              <Link to="/finder" className="btn btn--outline">Edit answers</Link>
            </>
          ) : (
            <Link to="/finder" className="btn btn--primary">
              Start the Car Finder <ArrowRightIcon />
            </Link>
          )}
        </div>
      </section>

      <section className="section">
        <div className="section__head">
          <h2>Saved cars {cars.length > 0 && <span className="muted">({cars.length})</span>}</h2>
          {cars.length >= 2 && (
            <button type="button" className="btn btn--outline btn--small" onClick={compareSaved}>
              <CompareIcon /> Compare {cars.length > 3 ? 'first 3' : 'these'}
            </button>
          )}
        </div>
        {(!saved.data || !shortlistReady) && !saved.error && <Loading />}
        {saved.error && <ErrorState error={saved.error} onRetry={saved.reload} />}
        {saved.data && shortlistReady && cars.length === 0 && (
          <EmptyState title="No saved cars yet" action={<Link to="/cars" className="btn btn--primary">Browse cars</Link>}>
            Tap the heart on any car to keep it here for later.
          </EmptyState>
        )}
        {shortlistReady && cars.length > 0 && (
          <div className="card-grid">
            {cars.map((car) => (
              <CarCard key={car.slug} car={car} />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
