import { useEffect } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { useApi } from '../api.js';
import { MAX_COMPARE, useCompare } from '../context/CompareContext.jsx';
import CarArt from '../components/CarArt.jsx';
import ShortlistButton from '../components/ShortlistButton.jsx';
import { AlertIcon, CheckIcon, CloseIcon } from '../components/Icons.jsx';
import { ErrorState, Loading } from '../components/States.jsx';
import { BODY_LABELS, bootText, displacement, headlineMileage, ncapText, priceRange, range, seatsText } from '../format.js';

// Each row: how to display a car's value, and optionally how to pick the best one.
const ROWS = [
  { group: 'Overview' },
  { label: 'Price (ex-showroom)', render: (c) => priceRange(c.price), value: (c) => c.price.min, best: 'min', verdict: 'Most affordable' },
  { label: 'Body type', render: (c) => BODY_LABELS[c.bodyType] },
  { label: 'Seating', render: seatsText, value: (c) => c.seatingMax, best: 'max', verdict: 'Most seats' },
  { group: 'Engine & performance' },
  { label: 'Engine / battery', render: displacement },
  {
    label: 'Engine options',
    render: (c) => (
      <ul className="plain-list">
        {c.engines.map((e) => (
          <li key={e.name}>{e.name} <span className="muted">({e.fuel}, {e.powerBhp} bhp)</span></li>
        ))}
      </ul>
    ),
  },
  { label: 'Max power', render: (c) => `${c.maxPowerBhp} bhp`, value: (c) => c.maxPowerBhp, best: 'max', verdict: 'Most powerful' },
  { label: 'Max torque', render: (c) => `${c.maxTorqueNm} Nm`, value: (c) => c.maxTorqueNm, best: 'max' },
  { label: 'Transmission', render: (c) => c.transmissions.join(', ') },
  { group: 'Fuel & efficiency' },
  { label: 'Fuel options', render: (c) => c.fuelTypes.join(', ') },
  { label: 'Claimed mileage', render: headlineMileage, value: (c) => c.bestMileage, best: 'max', verdict: 'Most efficient' },
  { label: 'CNG mileage', render: (c) => (c.mileage.CNG ? range(c.mileage.CNG, 'km/kg') : '—'), value: (c) => c.mileage.CNG?.[1] ?? null, best: 'max' },
  {
    label: 'Electric range',
    render: (c) => (c.mileage.Electric ? range(c.mileage.Electric, 'km') : '—'),
    value: (c) => c.mileage.Electric?.[1] ?? null,
    best: 'max',
  },
  { group: 'Practicality' },
  { label: 'Boot space', render: (c) => bootText(c.bootLitres), value: (c) => c.bootLitres, best: 'max', verdict: 'Biggest boot' },
  { label: 'Ground clearance', render: (c) => `${c.groundClearanceMm} mm`, value: (c) => c.groundClearanceMm, best: 'max' },
  { label: 'Length', render: (c) => `${c.lengthMm} mm` },
  { group: 'Safety' },
  { label: 'Crash-test rating', render: (c) => ncapText(c.safety), value: (c) => c.safety.stars, best: 'max', verdict: 'Best crash rating' },
  { label: 'Airbags (standard)', render: (c) => c.safety.airbags, value: (c) => c.safety.airbags, best: 'max' },
  { group: 'Torque Lab ratings' },
  { label: 'Comfort & features', render: (c) => `${c.comfort}/5`, value: (c) => c.comfort, best: 'max' },
  { label: 'Ease of ownership', render: (c) => `${c.ownership}/5`, value: (c) => c.ownership, best: 'max' },
  { group: 'Verdict' },
  {
    label: 'Pros',
    render: (c) => (
      <ul className="reason-list reason-list--good reason-list--compact">
        {c.pros.map((p) => <li key={p}><CheckIcon /> {p}</li>)}
      </ul>
    ),
  },
  {
    label: 'Cons',
    render: (c) => (
      <ul className="reason-list reason-list--bad reason-list--compact">
        {c.cons.map((p) => <li key={p}><AlertIcon /> {p}</li>)}
      </ul>
    ),
  },
];

// Returns the set of car slugs holding the best value for a row, or an empty set when there is no clear winner.
function winners(row, cars) {
  if (!row.best || cars.length < 2) return new Set();
  const values = cars.map((c) => ({ slug: c.slug, v: row.value(c) })).filter((x) => x.v != null);
  if (values.length < 2 && values.length !== cars.length) return new Set(values.map((x) => x.slug));
  const target = row.best === 'max' ? Math.max(...values.map((x) => x.v)) : Math.min(...values.map((x) => x.v));
  const best = values.filter((x) => x.v === target);
  return best.length === values.length ? new Set() : new Set(best.map((x) => x.slug));
}

function CarPicker({ cars, exclude, onPick, label = 'Add a car' }) {
  const brands = [...new Set(cars.map((c) => c.brand))];
  return (
    <label className="car-picker">
      <span>{label}</span>
      <select value="" onChange={(e) => e.target.value && onPick(e.target.value)}>
        <option value="">Choose a car…</option>
        {brands.map((b) => (
          <optgroup key={b} label={b}>
            {cars
              .filter((c) => c.brand === b && !exclude.includes(c.slug))
              .map((c) => (
                <option key={c.slug} value={c.slug}>{c.name}</option>
              ))}
          </optgroup>
        ))}
      </select>
    </label>
  );
}

export default function ComparePage() {
  const [params, setParams] = useSearchParams();
  const { items, replace, remove: removeFromTray } = useCompare();
  const slugs = (params.get('cars') || '').split(',').filter(Boolean).slice(0, MAX_COMPARE);

  // Arriving without ?cars= : show whatever is in the compare tray.
  useEffect(() => {
    if (!params.get('cars') && items.length) setParams({ cars: items.map((i) => i.slug).join(',') }, { replace: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const selected = useApi(slugs.length ? `/cars?slugs=${slugs.join(',')}` : null);
  const all = useApi('/cars?sort=name');
  const cars = slugs.length ? selected.data?.cars || [] : [];

  // Keep the compare tray in step with what this page shows (e.g. after opening a shared link).
  useEffect(() => {
    if (selected.data) replace(selected.data.cars);
  }, [selected.data, replace]);

  const setSlugs = (list) => setParams(list.length ? { cars: list.join(',') } : {}, { replace: true });
  const add = (slug) => setSlugs([...slugs, slug].slice(0, MAX_COMPARE));
  const remove = (slug) => {
    removeFromTray(slug);
    setSlugs(slugs.filter((s) => s !== slug));
  };

  const catalogue = all.data?.cars || [];
  const emptySlots = MAX_COMPARE - cars.length;
  const verdicts = ROWS.filter((r) => r.verdict)
    .map((r) => {
      const w = winners(r, cars);
      return w.size === 1 ? { label: r.verdict, car: cars.find((c) => w.has(c.slug)) } : null;
    })
    .filter(Boolean);

  return (
    <div className="container page">
      <header className="page-head">
        <div>
          <h1>Compare cars</h1>
          <p className="muted">Pick up to {MAX_COMPARE} cars to see them side by side. The best value in each row is highlighted.</p>
        </div>
      </header>

      {all.error && <ErrorState error={all.error} onRetry={all.reload} />}
      {selected.error && <ErrorState error={selected.error} onRetry={selected.reload} />}
      {slugs.length > 0 && !selected.data && selected.loading && <Loading label="Loading cars…" />}

      {cars.length === 0 && !selected.loading && (
        <div className="panel compare-empty">
          <p>Choose cars below, or tick <strong>Compare</strong> on any car while browsing.</p>
          <div className="compare-empty__pickers">
            {Array.from({ length: MAX_COMPARE }, (_, i) => (
              <CarPicker key={i} cars={catalogue} exclude={slugs} onPick={add} label={`Car ${i + 1}`} />
            ))}
          </div>
          <Link to="/cars" className="btn btn--outline">Browse cars</Link>
        </div>
      )}

      {cars.length > 0 && (
        <>
          {verdicts.length > 0 && (
            <div className="verdicts" aria-label="Quick verdict">
              {verdicts.map((v) => (
                <div key={v.label} className="verdict-card">
                  <span className="muted small">{v.label}</span>
                  <strong>{v.car.model}</strong>
                </div>
              ))}
            </div>
          )}

          <div className="table-wrap compare-wrap">
            <table className={`compare-table compare-table--${cars.length + Math.min(emptySlots, 1)}`}>
              <thead>
                <tr>
                  <th scope="col" className="compare-table__corner">
                    <span className="visually-hidden">Specification</span>
                  </th>
                  {cars.map((c) => (
                    <th key={c.slug} scope="col" className="compare-car">
                      <button type="button" className="icon-btn compare-car__remove" onClick={() => remove(c.slug)} aria-label={`Remove ${c.name}`}>
                        <CloseIcon size={16} />
                      </button>
                      <Link to={`/cars/${c.slug}`} className="compare-car__art" style={{ '--car': c.color }} tabIndex={-1} aria-hidden="true">
                        <CarArt bodyType={c.bodyType} color={c.color} />
                      </Link>
                      <span className="eyebrow">{c.brand}</span>
                      <Link to={`/cars/${c.slug}`} className="compare-car__name">{c.model}</Link>
                      <span className="compare-car__actions">
                        <ShortlistButton car={c} />
                      </span>
                    </th>
                  ))}
                  {emptySlots > 0 && (
                    <th scope="col" className="compare-car compare-car--empty">
                      <CarPicker cars={catalogue} exclude={slugs} onPick={add} />
                    </th>
                  )}
                </tr>
              </thead>
              <tbody>
                {ROWS.map((row) =>
                  row.group ? (
                    <tr key={row.group} className="compare-table__group">
                      <th scope="colgroup" colSpan={cars.length + (emptySlots > 0 ? 2 : 1)}>{row.group}</th>
                    </tr>
                  ) : (
                    <tr key={row.label}>
                      <th scope="row">{row.label}</th>
                      {(() => {
                        const best = winners(row, cars);
                        return cars.map((c) => (
                          <td key={c.slug} className={best.has(c.slug) ? 'is-best' : ''}>
                            {row.render(c)}
                            {best.has(c.slug) && <span className="best-badge">Best</span>}
                          </td>
                        ));
                      })()}
                      {emptySlots > 0 && <td className="compare-table__blank" />}
                    </tr>
                  ),
                )}
              </tbody>
            </table>
          </div>
        </>
      )}
    </div>
  );
}
