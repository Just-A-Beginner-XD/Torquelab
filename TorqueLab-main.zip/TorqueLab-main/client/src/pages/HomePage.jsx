import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useApi } from '../api.js';
import CarArt from '../components/CarArt.jsx';
import CarCard from '../components/CarCard.jsx';
import { ArrowRightIcon, CheckIcon, ShieldIcon, GaugeIcon, RoadIcon } from '../components/Icons.jsx';
import { ErrorState, Loading } from '../components/States.jsx';

const POPULAR = ['maruti-suzuki-swift', 'tata-nexon', 'hyundai-creta', 'volkswagen-virtus', 'maruti-suzuki-ertiga', 'tata-punch'];

const BODY_BLURBS = {
  hatchback: { color: '#d63a2f', text: 'Compact, frugal and easy to park.' },
  sedan: { color: '#2167d8', text: 'Stable on highways, with a big boot.' },
  suv: { color: '#d99a12', text: 'High seating and ground clearance.' },
  muv: { color: '#6e6259', text: 'Seven seats for big families.' },
};

const BUDGETS = [
  { value: '', label: 'Any budget' },
  { value: '6', label: 'Under ₹6 Lakh' },
  { value: '8', label: 'Under ₹8 Lakh' },
  { value: '10', label: 'Under ₹10 Lakh' },
  { value: '15', label: 'Under ₹15 Lakh' },
  { value: '20', label: 'Under ₹20 Lakh' },
];

function QuickSearch({ bodyTypes }) {
  const navigate = useNavigate();
  const [budget, setBudget] = useState('');
  const [body, setBody] = useState('');

  const submit = (e) => {
    e.preventDefault();
    const params = new URLSearchParams();
    if (budget) params.set('maxPrice', budget);
    if (body) params.set('body', body);
    const query = params.toString(); // URLSearchParams.size is missing in Safari before 17
    navigate(`/cars${query ? `?${query}` : ''}`);
  };

  return (
    <form className="quick-search" onSubmit={submit} aria-label="Quick search">
      <label>
        <span>Budget</span>
        <select value={budget} onChange={(e) => setBudget(e.target.value)}>
          {BUDGETS.map((b) => (
            <option key={b.value} value={b.value}>{b.label}</option>
          ))}
        </select>
      </label>
      <label>
        <span>Body type</span>
        <select value={body} onChange={(e) => setBody(e.target.value)}>
          <option value="">All body types</option>
          {bodyTypes.map((b) => (
            <option key={b.type} value={b.type}>{b.label}</option>
          ))}
        </select>
      </label>
      <button type="submit" className="btn btn--primary">
        Search cars
      </button>
    </form>
  );
}

export default function HomePage() {
  const meta = useApi('/cars/meta');
  const popular = useApi(`/cars?slugs=${POPULAR.join(',')}`);
  const bodyTypes = meta.data?.bodyTypes || [
    { type: 'hatchback', label: 'Hatchback' },
    { type: 'sedan', label: 'Sedan' },
    { type: 'suv', label: 'SUV' },
    { type: 'muv', label: 'MUV' },
  ];

  return (
    <>
      <section className="hero">
        <div className="container hero__inner">
          <div className="hero__copy">
            <p className="hero__kicker">Car buying, explained</p>
            <h1>
              Find the <span>right</span> car, not just any car.
            </h1>
            <p className="hero__lead">
              Answer a few simple questions about your budget, family and daily drive. Torque Lab scores{' '}
              {meta.data?.total ?? 30} popular cars and tells you exactly why each one fits, and what you give up.
            </p>
            <div className="hero__cta">
              <Link to="/finder" className="btn btn--primary btn--large">
                Start the Car Finder <ArrowRightIcon />
              </Link>
              <Link to="/cars" className="btn btn--ghost-light btn--large">
                Browse all cars
              </Link>
            </div>
            <ul className="hero__points">
              <li><CheckIcon /> No sign-up needed</li>
              <li><CheckIcon /> Clear trade-offs for every pick</li>
              <li><CheckIcon /> Compare up to 3 cars</li>
            </ul>
          </div>
          <div className="hero__art" aria-hidden="true">
            <div className="hero__stage">
              <CarArt bodyType="suv" color="#e8461e" />
            </div>
          </div>
        </div>
        <div className="container">
          <QuickSearch bodyTypes={bodyTypes} />
        </div>
      </section>

      <section className="section container">
        <div className="section__head">
          <h2>Shop by body type</h2>
          <p className="muted">Not sure which one? The Car Finder works it out for you.</p>
        </div>
        <div className="body-grid">
          {bodyTypes.map((b) => (
            <Link key={b.type} to={`/cars?body=${b.type}`} className="body-tile">
              <CarArt bodyType={b.type} color={BODY_BLURBS[b.type].color} />
              <div>
                <h3>{b.label}</h3>
                <p>{BODY_BLURBS[b.type].text}</p>
                {b.count != null && <span className="muted small">{b.count} models</span>}
              </div>
            </Link>
          ))}
        </div>
      </section>

      <section className="section section--tinted">
        <div className="container how">
          <div>
            <p className="eyebrow">How the Car Finder works</p>
            <h2>Recommendations you can actually understand</h2>
            <p className="muted">
              No black-box AI. Torque Lab uses transparent rules: it filters out cars that break your must-haves, then
              scores the rest on what matters to you.
            </p>
            <Link to="/finder" className="btn btn--primary">
              Find my car <ArrowRightIcon />
            </Link>
          </div>
          <ol className="how__steps">
            <li>
              <span className="how__icon"><GaugeIcon size={22} /></span>
              <div>
                <h3>Tell us about you</h3>
                <p>Budget, family size, daily distance, the roads you drive and the mileage you expect.</p>
              </div>
            </li>
            <li>
              <span className="how__icon"><RoadIcon size={22} /></span>
              <div>
                <h3>We pick the body type and fuel</h3>
                <p>Hatchback, sedan, SUV or MUV, plus petrol, diesel, CNG or hybrid, with the cost maths shown.</p>
              </div>
            </li>
            <li>
              <span className="how__icon"><ShieldIcon size={22} /></span>
              <div>
                <h3>Get ranked matches, with trade-offs</h3>
                <p>Every car comes with reasons it fits, honest downsides and the variant we would choose.</p>
              </div>
            </li>
          </ol>
        </div>
      </section>

      <section className="section container">
        <div className="section__head">
          <h2>Popular picks</h2>
          <Link to="/cars" className="link-arrow">
            See all cars <ArrowRightIcon />
          </Link>
        </div>
        {popular.loading && <Loading />}
        {popular.error && <ErrorState error={popular.error} onRetry={popular.reload} />}
        {popular.data && (
          <div className="card-grid card-grid--3">
            {popular.data.cars.map((car) => (
              <CarCard key={car.slug} car={car} />
            ))}
          </div>
        )}
      </section>

      {meta.data && (
        <section className="section container">
          <div className="section__head">
            <h2>Browse by brand</h2>
          </div>
          <div className="brand-grid">
            {meta.data.brands.map((b) => (
              <Link key={b.name} to={`/cars?brand=${encodeURIComponent(b.name)}`} className="brand-tile">
                <span className="brand-tile__mark" aria-hidden="true">
                  {b.name.length <= 3 ? b.name : b.name.split(' ').map((w) => w[0]).join('').slice(0, 2)}
                </span>
                <span>
                  <strong>{b.name}</strong>
                  <small>{b.count} {b.count === 1 ? 'model' : 'models'}</small>
                </span>
              </Link>
            ))}
          </div>
        </section>
      )}
    </>
  );
}
