import { Link, useParams } from 'react-router-dom';
import { useApi } from '../api.js';
import CarArt from '../components/CarArt.jsx';
import CarCard from '../components/CarCard.jsx';
import CompareToggle from '../components/CompareToggle.jsx';
import ShortlistButton from '../components/ShortlistButton.jsx';
import { AlertIcon, ArrowRightIcon, CheckIcon, FuelIcon, GaugeIcon, GearIcon, SeatIcon, ShieldIcon } from '../components/Icons.jsx';
import { EmptyState, ErrorState, Loading } from '../components/States.jsx';
import {
  BODY_LABELS,
  displacement,
  gearboxSummary,
  headlineMileage,
  lakh,
  mileageUnit,
  ncapText,
  priceRange,
  range,
  seatsText,
  bootText,
  isElectric,
} from '../format.js';

function Rating({ label, value, hint }) {
  return (
    <div className="rating">
      <div className="rating__head">
        <span>{label}</span>
        <strong>{value}/5</strong>
      </div>
      <div className="meter" aria-hidden="true">
        <span style={{ width: `${value * 20}%` }} />
      </div>
      <p className="muted small">{hint}</p>
    </div>
  );
}

// Live data: the brand's current US line-up from the NHTSA vehicle database (cached on the server).
function GlobalLineup({ car }) {
  const { data, error, loading, reload } = useApi(`/cars/${car.slug}/global`);
  const fetched = data?.fetchedAt ? new Date(data.fetchedAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }) : null;

  return (
    <section className="panel">
      <div className="panel__head">
        <h2>Global line-up</h2>
        {data?.available && (
          <span className="live-badge">
            <span aria-hidden="true" /> Live · NHTSA
          </span>
        )}
      </div>
      {loading && <Loading label="Fetching live data…" />}
      {error && <ErrorState error={error} onRetry={reload} />}
      {data && !data.available && <p className="muted">{data.reason}</p>}
      {data?.available && (
        <>
          {data.models.length === 0 ? (
            <p>
              The US vehicle database lists no {data.make} cars for the {data.years.join('–')} model years, so {car.brand} has
              no current US line-up.
            </p>
          ) : (
            <>
              <p>
                {data.make} sells {data.models.length} cars and SUVs in the US for the {data.years.join('–')} model years.{' '}
                {data.match ? (
                  <>
                    The <strong>{car.model}</strong> is sold there too, as the <strong>{data.match}</strong>.
                  </>
                ) : (
                  <>The {car.model} is not part of that line-up; it is built for India and other markets.</>
                )}
              </p>
              <ul className="chip-set">
                {data.models.map((m) => (
                  <li key={m} className={`chip ${m === data.match ? 'chip--good' : ''}`}>
                    {m}
                  </li>
                ))}
              </ul>
            </>
          )}
          <p className="muted small lineup-source">
            Source: US NHTSA Product Information Catalog (vPIC){fetched ? `, fetched ${fetched}` : ''}
            {data.stale ? ' (could not refresh, showing the last saved copy)' : ''}.
          </p>
        </>
      )}
    </section>
  );
}

export default function CarDetailPage() {
  const { slug } = useParams();
  const { data, error, loading, reload } = useApi(`/cars/${slug}`);

  if (loading) return <div className="container page"><Loading label="Loading car…" /></div>;
  if (error?.status === 404) {
    return (
      <div className="container page">
        <EmptyState title="We couldn’t find that car" action={<Link to="/cars" className="btn btn--primary">Browse all cars</Link>}>
          It may have been removed from the catalogue.
        </EmptyState>
      </div>
    );
  }
  if (error) return <div className="container page"><ErrorState error={error} onRetry={reload} /></div>;

  const { car, similar } = data;
  const specs = [
    {
      label: isElectric(car) ? 'Battery' : 'Engine',
      value: displacement(car),
      sub: `${car.engines.length} option${car.engines.length > 1 ? 's' : ''}`,
    },
    { label: 'Max power', value: `${car.maxPowerBhp} bhp` },
    { label: 'Max torque', value: `${car.maxTorqueNm} Nm` },
    { label: 'Fuel', value: car.fuelTypes.join(', ') },
    { label: 'Transmission', value: car.transmissions.join(', ') },
    { label: isElectric(car) ? 'Claimed range' : 'Claimed mileage', value: headlineMileage(car) },
    { label: 'Seating', value: seatsText(car) },
    { label: 'Ground clearance', value: `${car.groundClearanceMm} mm` },
    { label: 'Boot space', value: bootText(car.bootLitres) },
    { label: 'Length', value: `${car.lengthMm} mm`, sub: car.lengthMm <= 4000 ? 'Sub-4 metre' : null },
    { label: 'Safety rating', value: ncapText(car.safety) },
    { label: 'Airbags', value: `${car.safety.airbags} (standard)` },
  ];

  return (
    <div className="page">
      <section className="detail-hero">
        <div className="container">
          <nav className="breadcrumbs" aria-label="Breadcrumb">
            <Link to="/">Home</Link> / <Link to="/cars">Cars</Link> / <Link to={`/cars?brand=${encodeURIComponent(car.brand)}`}>{car.brand}</Link> /{' '}
            <span aria-current="page">{car.model}</span>
          </nav>
          <div className="detail-hero__grid">
            <div className="detail-hero__art" style={{ '--car': car.color }}>
              <CarArt bodyType={car.bodyType} color={car.color} label={`Illustration of the ${car.name}`} />
            </div>
            <div className="detail-hero__info">
              <p className="eyebrow">{car.brand}</p>
              <h1>{car.model}</h1>
              <div className="chip-set">
                <span className="chip">{BODY_LABELS[car.bodyType]}</span>
                {car.safety.stars && (
                  <span className="chip chip--good">
                    <ShieldIcon size={14} /> {ncapText(car.safety)}
                  </span>
                )}
                <span className="chip">{seatsText(car)}</span>
              </div>
              <p className="detail-hero__summary">{car.summary}</p>
              <p className="detail-hero__price">
                {priceRange(car.price)}
                <small>Indicative ex-showroom price</small>
              </p>
              <ul className="spec-row spec-row--large">
                <li><GaugeIcon /> {headlineMileage(car)}</li>
                <li><FuelIcon /> {car.fuelTypes.join(' · ')}</li>
                <li><GearIcon /> {gearboxSummary(car)}</li>
                <li><SeatIcon /> {seatsText(car)}</li>
              </ul>
              <div className="detail-hero__actions">
                <CompareToggle car={car} variant="button" />
                <ShortlistButton car={car} withLabel />
                <Link to="/finder" className="btn btn--ghost">
                  Is it right for me? <ArrowRightIcon />
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      <div className="container detail-body">
        <section className="panel">
          <h2>Key specifications</h2>
          <dl className="spec-grid">
            {specs.map((s) => (
              <div key={s.label}>
                <dt>{s.label}</dt>
                <dd>
                  {s.value}
                  {s.sub && <small>{s.sub}</small>}
                </dd>
              </div>
            ))}
          </dl>
        </section>

        <section className="panel">
          <h2>Pros and cons</h2>
          <div className="pros-cons">
            <div>
              <h3 className="pros-title">What we like</h3>
              <ul className="reason-list reason-list--good">
                {car.pros.map((p) => (
                  <li key={p}><CheckIcon /> {p}</li>
                ))}
              </ul>
            </div>
            <div>
              <h3 className="cons-title">What to consider</h3>
              <ul className="reason-list reason-list--bad">
                {car.cons.map((c) => (
                  <li key={c}><AlertIcon /> {c}</li>
                ))}
              </ul>
            </div>
          </div>
        </section>

        <div className="detail-two">
          <section className="panel">
            <h2>Engine options</h2>
            <div className="table-wrap">
              <table className="table">
                <thead>
                  <tr>
                    <th scope="col">Engine</th>
                    <th scope="col">Fuel</th>
                    <th scope="col">Size</th>
                    <th scope="col">Power</th>
                    <th scope="col">Torque</th>
                  </tr>
                </thead>
                <tbody>
                  {car.engines.map((e) => (
                    <tr key={e.name}>
                      <th scope="row">{e.name}</th>
                      <td>{e.fuel}</td>
                      <td>{e.cc ? `${e.cc} cc, ${e.cylinders}-cyl` : `${e.batteryKwh} kWh`}</td>
                      <td>{e.powerBhp} bhp</td>
                      <td>{e.torqueNm} Nm</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>

          <section className="panel">
            <h2>Fuel options</h2>
            <div className="table-wrap">
              <table className="table">
                <thead>
                  <tr>
                    <th scope="col">Fuel</th>
                    <th scope="col">Starts at</th>
                    <th scope="col">Claimed efficiency</th>
                  </tr>
                </thead>
                <tbody>
                  {car.fuelTypes.map((f) => (
                    <tr key={f}>
                      <th scope="row">{f}</th>
                      <td>{lakh(car.fuelFrom[f])}</td>
                      <td>{range(car.mileage[f], mileageUnit(f))}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <p className="muted small">Starting prices for non-base fuels are estimates where exact variant prices are not listed.</p>
          </section>
        </div>

        <section className="panel">
          <h2>Torque Lab ratings</h2>
          <div className="ratings">
            <Rating label="Comfort & features" value={car.comfort} hint="Ride quality, cabin and equipment for the price." />
            <Rating label="Ease of ownership" value={car.ownership} hint="Service cost, workshop network and resale value." />
          </div>
        </section>

        <GlobalLineup car={car} />

        {similar.length > 0 && (
          <section className="section">
            <div className="section__head">
              <h2>Similar cars</h2>
            </div>
            <div className="card-grid card-grid--3">
              {similar.map((c) => (
                <CarCard key={c.slug} car={c} />
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}
