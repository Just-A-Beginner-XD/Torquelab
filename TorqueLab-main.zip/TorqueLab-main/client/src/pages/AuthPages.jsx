import { useState } from 'react';
import { Link, Navigate, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import { Logo } from '../components/Navbar.jsx';
import { AlertIcon } from '../components/Icons.jsx';

function Field({ label, error, ...props }) {
  const id = `field-${props.name}`;
  return (
    <div className={`field ${error ? 'has-error' : ''}`}>
      <label htmlFor={id}>{label}</label>
      <input id={id} aria-invalid={Boolean(error)} aria-describedby={error ? `${id}-error` : undefined} {...props} />
      {error && <p id={`${id}-error`} className="field__error">{error}</p>}
    </div>
  );
}

function AuthLayout({ title, subtitle, children, footer }) {
  const location = useLocation();
  const message = location.state?.message;
  return (
    <div className="auth container">
      <div className="auth__card panel">
        <Logo />
        <h1>{title}</h1>
        <p className="muted">{subtitle}</p>
        {message && <p className="notice">{message}</p>}
        {children}
        <p className="auth__footer">{footer}</p>
      </div>
    </div>
  );
}

function useAfterAuth() {
  const location = useLocation();
  const navigate = useNavigate();
  const from = location.state?.from;
  const target = from ? `${from.pathname}${from.search || ''}` : '/garage';
  return { target, go: () => navigate(target, { replace: true }), state: location.state };
}

export function LoginPage() {
  const { user, login } = useAuth();
  const after = useAfterAuth();
  const [form, setForm] = useState({ email: '', password: '' });
  const [error, setError] = useState(null);
  const [busy, setBusy] = useState(false);

  if (user && !busy) return <Navigate to={after.target} replace />;

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await login(form.email, form.password);
      after.go();
    } catch (err) {
      setError(err.message);
      setBusy(false);
    }
  };
  const change = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  return (
    <AuthLayout
      title="Welcome back"
      subtitle="Log in to see your saved cars and Car Finder answers."
      footer={<>New to Torque Lab? <Link to="/signup" state={after.state}>Create an account</Link></>}
    >
      <form onSubmit={submit} noValidate>
        {error && <p className="notice notice--error" role="alert"><AlertIcon /> {error}</p>}
        <Field label="Email" name="email" type="email" autoComplete="email" value={form.email} onChange={change} required />
        <Field label="Password" name="password" type="password" autoComplete="current-password" value={form.password} onChange={change} required />
        <button type="submit" className="btn btn--primary btn--block" disabled={busy}>
          {busy ? 'Logging in…' : 'Log in'}
        </button>
      </form>
    </AuthLayout>
  );
}

export function SignupPage() {
  const { user, signup } = useAuth();
  const after = useAfterAuth();
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [fields, setFields] = useState({});
  const [error, setError] = useState(null);
  const [busy, setBusy] = useState(false);

  if (user && !busy) return <Navigate to={after.target} replace />;

  const validate = () => {
    const f = {};
    if (form.name.trim().length < 2) f.name = 'Please enter your name.';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email.trim())) f.email = 'Please enter a valid email address.';
    if (form.password.length < 8) f.password = 'Password must be at least 8 characters.';
    return f;
  };

  const submit = async (e) => {
    e.preventDefault();
    const f = validate();
    setFields(f);
    if (Object.keys(f).length) return;
    setBusy(true);
    setError(null);
    try {
      await signup(form.name.trim(), form.email.trim(), form.password);
      after.go();
    } catch (err) {
      setError(err.message);
      setFields(err.body?.fields || {});
      setBusy(false);
    }
  };
  const change = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  return (
    <AuthLayout
      title="Create your account"
      subtitle="Save cars to your garage and keep your Car Finder answers. It’s free."
      footer={<>Already have an account? <Link to="/login" state={after.state}>Log in</Link></>}
    >
      <form onSubmit={submit} noValidate>
        {error && <p className="notice notice--error" role="alert"><AlertIcon /> {error}</p>}
        <Field label="Name" name="name" autoComplete="name" value={form.name} onChange={change} error={fields.name} required />
        <Field label="Email" name="email" type="email" autoComplete="email" value={form.email} onChange={change} error={fields.email} required />
        <Field
          label="Password"
          name="password"
          type="password"
          autoComplete="new-password"
          value={form.password}
          onChange={change}
          error={fields.password}
          placeholder="At least 8 characters"
          required
        />
        <button type="submit" className="btn btn--primary btn--block" disabled={busy}>
          {busy ? 'Creating account…' : 'Create account'}
        </button>
      </form>
    </AuthLayout>
  );
}
