import { useEffect, useRef, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { api } from '../api.js';
import { useAuth } from '../context/AuthContext.jsx';
import CarArt from '../components/CarArt.jsx';
import OptionGroup from '../components/OptionGroup.jsx';
import FinderResults from '../components/FinderResults.jsx';
import { ArrowLeftIcon, ArrowRightIcon, CheckIcon } from '../components/Icons.jsx';
import { ErrorState, Loading } from '../components/States.jsx';
import {
  BODY_OPTIONS,
  BUDGET_PRESETS,
  CONDITION_OPTIONS,
  DAILY_KM_OPTIONS,
  DEFAULT_ANSWERS,
  FAMILY_OPTIONS,
  FUEL_OPTIONS,
  MILEAGE_OPTIONS,
  PRIORITY_OPTIONS,
  TRANSMISSION_OPTIONS,
} from '../finderOptions.js';

const STORAGE_KEY = 'torque-lab:finder';
const STEPS = [
  { name: 'Budget', title: 'What’s your budget?', subtitle: 'The most you want to spend on the car itself (ex-showroom).' },
  { name: 'People', title: 'Who will usually be in the car?', subtitle: 'Count everyone on a typical drive, including you.' },
  { name: 'Driving', title: 'How will you drive it?', subtitle: 'Daily distance decides which fuel pays off; your roads decide the body type.' },
  { name: 'Fuel', title: 'Mileage, fuel and gearbox', subtitle: 'Not sure? Leave these on the defaults and we’ll suggest what makes sense.' },
  { name: 'Priorities', title: 'Anything else that matters?', subtitle: 'Optional. Pick a body type only if you have already decided.' },
];
const RESULTS = STEPS.length;

const BODY_COLORS = { hatchback: '#d63a2f', sedan: '#2167d8', suv: '#d99a12', muv: '#6e6259' };

function readSession() {
  try {
    return JSON.parse(sessionStorage.getItem(STORAGE_KEY)) || null;
  } catch {
    return null;
  }
}
function writeSession(value) {
  try {
    if (value) sessionStorage.setItem(STORAGE_KEY, JSON.stringify(value));
    else sessionStorage.removeItem(STORAGE_KEY);
  } catch {
    /* private mode etc. — results just won't survive a reload */
  }
}

export default function FinderPage() {
  const { user, ready } = useAuth();
  const [searchParams, setSearchParams] = useSearchParams();
  const runSaved = searchParams.get('run') === 'saved';
  const [session] = useState(() => (runSaved ? null : readSession()));

  const [answers, setAnswers] = useState(session?.answers || DEFAULT_ANSWERS);
  const [result, setResult] = useState(session?.result || null);
  const [step, setStep] = useState(session?.result ? RESULTS : 0);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);
  const [notice, setNotice] = useState(null);
  const prefilled = useRef(false);

  const set = (key) => (value) => setAnswers((a) => ({ ...a, [key]: value }));

  const submit = async (ans = answers) => {
    setSubmitting(true);
    setError(null);
    try {
      const data = await api('/recommendations', { method: 'POST', body: { answers: ans } });
      setResult(data);
      setStep(RESULTS);
      writeSession({ answers: ans, result: data });
      window.scrollTo(0, 0);
    } catch (err) {
      setError(err);
    } finally {
      setSubmitting(false);
    }
  };

  // Signed-in users start from their saved answers; /finder?run=saved shows results straight away.
  useEffect(() => {
    if (!ready || prefilled.current || session) return;
    prefilled.current = true;
    if (!user) return;
    api('/me/preferences')
      .then(({ preferences }) => {
        if (!preferences) return;
        const saved = { ...DEFAULT_ANSWERS, ...preferences };
        setAnswers(saved);
        if (runSaved) {
          setSearchParams({}, { replace: true });
          submit(saved);
        } else {
          setNotice('We loaded the answers you saved last time.');
        }
      })
      .catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ready, user]);

  // Coming back after logging in from the results page: re-run once so the answers get saved.
  useEffect(() => {
    if (user && result && !result.saved && step === RESULTS && !submitting) submit(answers);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  const restart = () => {
    writeSession(null);
    setResult(null);
    setAnswers(DEFAULT_ANSWERS);
    setNotice(null);
    setStep(0);
    window.scrollTo(0, 0);
  };
  const edit = () => {
    setStep(0);
    window.scrollTo(0, 0);
  };
  const go = (next) => {
    setStep(next);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  if (step === RESULTS && result) {
    return <FinderResults result={result} onEdit={edit} onRestart={restart} />;
  }
  if (runSaved && submitting) {
    return <div className="container page"><Loading label="Finding your matches…" /></div>;
  }

  const current = STEPS[step];
  const last = step === STEPS.length - 1;

  return (
    <div className="container page finder">
      <header className="finder__head">
        <p className="eyebrow">Car Finder · Step {step + 1} of {STEPS.length}</p>
        <h1>{current.title}</h1>
        <p className="muted">{current.subtitle}</p>
      </header>

      <ol className="stepper" aria-label="Progress">
        {STEPS.map((s, i) => (
          <li key={s.name} className={i < step ? 'is-done' : i === step ? 'is-current' : ''}>
            <button type="button" onClick={() => i < step && go(i)} disabled={i >= step} aria-current={i === step ? 'step' : undefined}>
              <span className="stepper__dot">{i < step ? <CheckIcon size={14} /> : i + 1}</span>
              <span className="stepper__name">{s.name}</span>
            </button>
          </li>
        ))}
      </ol>

      {notice && step === 0 && <p className="notice notice--good"><CheckIcon /> {notice}</p>}

      <form
        className="panel finder__panel"
        onSubmit={(e) => {
          e.preventDefault();
          if (last) submit();
          else go(step + 1);
        }}
      >
        {step === 0 && (
          <div className="budget-pick">
            <output className="budget-pick__value" htmlFor="finder-budget">
              ₹{answers.budget} <span>Lakh</span>
            </output>
            <input
              id="finder-budget"
              type="range"
              min="3"
              max="50"
              step="0.5"
              value={answers.budget}
              onChange={(e) => set('budget')(Number(e.target.value))}
              aria-label="Budget in lakh rupees"
            />
            <div className="range-labels">
              <span>₹3 Lakh</span>
              <span>₹50 Lakh</span>
            </div>
            <div className="chip-set chip-set--center">
              {BUDGET_PRESETS.map((v) => (
                <button key={v} type="button" className={`chip chip--toggle ${answers.budget === v ? 'is-active' : ''}`} aria-pressed={answers.budget === v} onClick={() => set('budget')(v)}>
                  ₹{v}L
                </button>
              ))}
            </div>
            <p className="tip">
              <strong>Tip:</strong> the on-road price (with insurance and registration) is usually 10–15% higher. A ₹
              {answers.budget} Lakh car costs roughly ₹{(answers.budget * 1.12).toFixed(1)} Lakh on the road.
            </p>
          </div>
        )}

        {step === 1 && (
          <>
            <OptionGroup legend="How many people?" name="familySize" options={FAMILY_OPTIONS} value={answers.familySize} onChange={set('familySize')} columns={4} />
            <label className="switch">
              <input type="checkbox" checked={answers.newDriver} onChange={(e) => set('newDriver')(e.target.checked)} />
              <span className="switch__track" aria-hidden="true" />
              <span>
                <strong>I’m a new driver</strong>
                <small>We’ll favour cars that are easy to drive and park, ideally with an automatic option.</small>
              </span>
            </label>
          </>
        )}

        {step === 2 && (
          <>
            <OptionGroup legend="How far do you drive on a typical day?" name="dailyKm" options={DAILY_KM_OPTIONS} value={answers.dailyKm} onChange={set('dailyKm')} columns={4} />
            <OptionGroup legend="Where do you drive most?" name="conditions" options={CONDITION_OPTIONS} value={answers.conditions} onChange={set('conditions')} columns={4} />
          </>
        )}

        {step === 3 && (
          <>
            <OptionGroup legend="What mileage do you expect?" name="mileagePref" options={MILEAGE_OPTIONS} value={answers.mileagePref} onChange={set('mileagePref')} columns={4} hint="Claimed (ARAI) figures. Real-world mileage is usually 15–25% lower." />
            <OptionGroup legend="Fuel type" name="fuel" options={FUEL_OPTIONS} value={answers.fuel} onChange={set('fuel')} columns={3} />
            <OptionGroup legend="Gearbox" name="transmission" options={TRANSMISSION_OPTIONS} value={answers.transmission} onChange={set('transmission')} columns={3} />
          </>
        )}

        {step === 4 && (
          <>
            <OptionGroup
              legend="Body type"
              name="bodyType"
              options={BODY_OPTIONS.map((o) => ({
                ...o,
                icon: o.value !== 'any' ? <CarArt bodyType={o.value} color={BODY_COLORS[o.value]} /> : null,
              }))}
              value={answers.bodyType}
              onChange={set('bodyType')}
              columns={5}
            />
            <OptionGroup
              legend="What matters most to you?"
              hint="Pick up to 3."
              name="priorities"
              options={PRIORITY_OPTIONS}
              value={answers.priorities}
              onChange={set('priorities')}
              multiple
              max={3}
              columns={5}
            />
          </>
        )}

        {error && <ErrorState error={error} />}

        <div className="finder__nav">
          <button type="button" className="btn btn--ghost" onClick={() => go(step - 1)} disabled={step === 0}>
            <ArrowLeftIcon /> Back
          </button>
          <button type="submit" className="btn btn--primary btn--large" disabled={submitting}>
            {last ? (submitting ? 'Finding matches…' : 'Show my matches') : 'Next'} <ArrowRightIcon />
          </button>
        </div>
      </form>
      {result && (
        <p className="muted small finder__back">
          <button type="button" className="link-btn" onClick={() => go(RESULTS)}>
            Back to your previous results
          </button>
        </p>
      )}
    </div>
  );
}
