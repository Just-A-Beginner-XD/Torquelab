import { useEffect, useRef, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { useApi } from '../api.js';
import CarCard from '../components/CarCard.jsx';
import { CloseIcon, FilterIcon, SearchIcon } from '../components/Icons.jsx';
import { EmptyState, ErrorState, Loading } from '../components/States.jsx';
import { BODY_LABELS } from '../format.js';

const MAX_BUDGET = 50; // slider at max means "any budget"
const SORTS = [
  { value: 'price-asc', label: 'Price: low to high' },
  { value: 'price-desc', label: 'Price: high to low' },
  { value: 'mileage-desc', label: 'Best mileage' },
  { value: 'power-desc', label: 'Most powerful' },
  { value: 'name', label: 'Name (A–Z)' },
];
const FILTER_KEYS = ['brand', 'body', 'fuel', 'transmission', 'maxPrice', 'minSeats', 'q'];

export default function CarsPage() {
  const [params, setParams] = useSearchParams();
  const query = params.toString();
  const meta = useApi('/cars/meta');
  const list = useApi(`/cars${query ? `?${query}` : ''}`);
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [search, setSearch] = useState(params.get('q') || '');
  const [budget, setBudget] = useState(Number(params.get('maxPrice')) || MAX_BUDGET);

  const getList = (key) => (params.get(key) || '').split(',').filter(Boolean);

  // Functional update so debounced writes never overwrite a filter changed in the meantime.
  const update = (changes) =>
    setParams(
      (prev) => {
        const next = new URLSearchParams(prev);
        for (const [key, value] of Object.entries(changes)) {
          const empty = value == null || value === '' || (Array.isArray(value) && !value.length);
          if (empty) next.delete(key);
          else next.set(key, Array.isArray(value) ? value.join(',') : String(value));
        }
        return next;
      },
      { replace: true },
    );
  const toggleIn = (key, value) => {
    const current = getList(key);
    update({ [key]: current.includes(value) ? current.filter((v) => v !== value) : [...current, value] });
  };

  // Search text and the budget slider are debounced before they reach the URL (and refetch).
  // `written` remembers what we last wrote, so a URL change made elsewhere (a link, the back
  // button) can be copied back into the inputs without clobbering what the user is typing.
  const written = useRef({ q: params.get('q') || '', maxPrice: params.get('maxPrice') || '' });
  useEffect(() => {
    const q = search.trim();
    const t = setTimeout(() => {
      written.current.q = q;
      update({ q });
    }, 300);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search]);
  useEffect(() => {
    const maxPrice = budget >= MAX_BUDGET ? '' : String(budget);
    const t = setTimeout(() => {
      written.current.maxPrice = maxPrice;
      update({ maxPrice });
    }, 250);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [budget]);
  useEffect(() => {
    const q = params.get('q') || '';
    const maxPrice = params.get('maxPrice') || '';
    if (q !== written.current.q) {
      written.current.q = q;
      setSearch(q);
    }
    if (maxPrice !== written.current.maxPrice) {
      written.current.maxPrice = maxPrice;
      setBudget(Number(maxPrice) || MAX_BUDGET);
    }
  }, [params]);

  const clearAll = () => {
    written.current = { q: '', maxPrice: '' };
    setSearch('');
    setBudget(MAX_BUDGET);
    const next = new URLSearchParams();
    if (params.get('sort')) next.set('sort', params.get('sort'));
    setParams(next, { replace: true });
  };

  const activeChips = [
    ...getList('brand').map((v) => ({ key: 'brand', value: v, label: v })),
    ...getList('body').map((v) => ({ key: 'body', value: v, label: BODY_LABELS[v] || v })),
    ...getList('fuel').map((v) => ({ key: 'fuel', value: v, label: v })),
  ];
  if (params.get('transmission')) activeChips.push({ key: 'transmission', label: params.get('transmission') === 'automatic' ? 'Automatic' : 'Manual' });
  if (params.get('minSeats')) activeChips.push({ key: 'minSeats', label: `${params.get('minSeats')}+ seats` });
  if (params.get('maxPrice')) activeChips.push({ key: 'maxPrice', label: `Up to ₹${params.get('maxPrice')} Lakh` });
  if (params.get('q')) activeChips.push({ key: 'q', label: `“${params.get('q')}”` });
  const activeCount = FILTER_KEYS.filter((k) => params.get(k)).length;

  const removeChip = (chip) => {
    if (chip.key === 'q') setSearch('');
    if (chip.key === 'maxPrice') setBudget(MAX_BUDGET);
    if (chip.value) toggleIn(chip.key, chip.value);
    else update({ [chip.key]: null });
  };

  return (
    <div className="container page">
      <header className="page-head">
        <div>
          <h1>Browse cars</h1>
          <p className="muted">
            {meta.data ? `${meta.data.total} models from ${meta.data.brands.length} brands.` : 'Explore popular models.'}{' '}
            Not sure where to start? <Link to="/finder">Try the Car Finder</Link>.
          </p>
        </div>
      </header>

      <div className="browse">
        <aside className={`filters ${filtersOpen ? 'is-open' : ''}`} aria-label="Filters">
          <div className="filters__head">
            <h2>Filters</h2>
            {activeCount > 0 && (
              <button type="button" className="link-btn" onClick={clearAll}>
                Clear all
              </button>
            )}
            <button type="button" className="icon-btn filters__close" onClick={() => setFiltersOpen(false)} aria-label="Close filters">
              <CloseIcon />
            </button>
          </div>

          <div className="filter-block">
            <label className="search-field">
              <SearchIcon />
              <input type="search" placeholder="Search model or brand" value={search} onChange={(e) => setSearch(e.target.value)} aria-label="Search cars" />
            </label>
          </div>

          <div className="filter-block">
            <label htmlFor="budget" className="filter-title">
              Budget <span className="filter-value">{budget >= MAX_BUDGET ? 'Any' : `Up to ₹${budget} Lakh`}</span>
            </label>
            <input id="budget" type="range" min="4" max={MAX_BUDGET} step="1" value={budget} onChange={(e) => setBudget(Number(e.target.value))} />
            <div className="range-labels">
              <span>₹4L</span>
              <span>Any</span>
            </div>
          </div>

          <fieldset className="filter-block">
            <legend className="filter-title">Body type</legend>
            <div className="chip-set">
              {['hatchback', 'sedan', 'suv', 'muv'].map((b) => (
                <button key={b} type="button" className={`chip chip--toggle ${getList('body').includes(b) ? 'is-active' : ''}`} aria-pressed={getList('body').includes(b)} onClick={() => toggleIn('body', b)}>
                  {BODY_LABELS[b]}
                </button>
              ))}
            </div>
          </fieldset>

          <fieldset className="filter-block">
            <legend className="filter-title">Brand</legend>
            {(meta.data?.brands || []).map((b) => (
              <label key={b.name} className="check">
                <input type="checkbox" checked={getList('brand').includes(b.name)} onChange={() => toggleIn('brand', b.name)} />
                <span>{b.name}</span>
                <small>{b.count}</small>
              </label>
            ))}
          </fieldset>

          <fieldset className="filter-block">
            <legend className="filter-title">Fuel</legend>
            {(meta.data?.fuels || []).map((f) => (
              <label key={f.fuel} className="check">
                <input type="checkbox" checked={getList('fuel').includes(f.fuel)} onChange={() => toggleIn('fuel', f.fuel)} />
                <span>{f.fuel}</span>
                <small>{f.count}</small>
              </label>
            ))}
          </fieldset>

          <fieldset className="filter-block">
            <legend className="filter-title">Transmission</legend>
            {[['', 'Any'], ['manual', 'Manual'], ['automatic', 'Automatic']].map(([v, label]) => (
              <label key={label} className="check">
                <input type="radio" name="transmission" checked={(params.get('transmission') || '') === v} onChange={() => update({ transmission: v })} />
                <span>{label}</span>
              </label>
            ))}
          </fieldset>

          <fieldset className="filter-block">
            <legend className="filter-title">Seats</legend>
            {[['', 'Any'], ['5', '5 or more'], ['7', '7 or more']].map(([v, label]) => (
              <label key={label} className="check">
                <input type="radio" name="seats" checked={(params.get('minSeats') || '') === v} onChange={() => update({ minSeats: v })} />
                <span>{label}</span>
              </label>
            ))}
          </fieldset>

          <button type="button" className="btn btn--primary filters__done" onClick={() => setFiltersOpen(false)}>
            Show {list.data ? list.data.total : ''} cars
          </button>
        </aside>

        <section className="results" aria-live="polite">
          <div className="results__bar">
            <button type="button" className="btn btn--outline btn--small filters__open" onClick={() => setFiltersOpen(true)}>
              <FilterIcon /> Filters {activeCount > 0 && <span className="badge">{activeCount}</span>}
            </button>
            <p className="results__count">{list.data ? `${list.data.total} ${list.data.total === 1 ? 'car' : 'cars'}` : ' '}</p>
            <label className="sort">
              <span>Sort</span>
              <select value={params.get('sort') || 'price-asc'} onChange={(e) => update({ sort: e.target.value === 'price-asc' ? null : e.target.value })}>
                {SORTS.map((s) => (
                  <option key={s.value} value={s.value}>{s.label}</option>
                ))}
              </select>
            </label>
          </div>

          {activeChips.length > 0 && (
            <div className="chip-set active-filters">
              {activeChips.map((chip) => (
                <span key={`${chip.key}-${chip.label}`} className="chip chip--removable">
                  {chip.label}
                  <button type="button" onClick={() => removeChip(chip)} aria-label={`Remove filter ${chip.label}`}>
                    <CloseIcon size={14} />
                  </button>
                </span>
              ))}
            </div>
          )}

          {list.loading && !list.data && <Loading label="Loading cars…" />}
          {list.error && <ErrorState error={list.error} onRetry={list.reload} />}
          {list.data && list.data.cars.length === 0 && (
            <EmptyState
              title="No cars match these filters"
              action={<button type="button" className="btn btn--primary" onClick={clearAll}>Clear filters</button>}
            >
              Try widening your budget or removing a filter.
            </EmptyState>
          )}
          {list.data && list.data.cars.length > 0 && (
            <div className={`card-grid ${list.loading ? 'is-loading' : ''}`}>
              {list.data.cars.map((car) => (
                <CarCard key={car.slug} car={car} />
              ))}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
