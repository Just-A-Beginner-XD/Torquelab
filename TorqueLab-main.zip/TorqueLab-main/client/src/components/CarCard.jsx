import { Link } from 'react-router-dom';
import CarArt from './CarArt.jsx';
import CompareToggle from './CompareToggle.jsx';
import ShortlistButton from './ShortlistButton.jsx';
import { FuelIcon, GaugeIcon, GearIcon, SeatIcon } from './Icons.jsx';
import { BODY_LABELS, gearboxSummary, headlineMileage, priceRange, seatsText } from '../format.js';

export default function CarCard({ car }) {
  return (
    <article className="car-card">
      <Link to={`/cars/${car.slug}`} className="car-card__media" style={{ '--car': car.color }} tabIndex={-1} aria-hidden="true">
        <CarArt bodyType={car.bodyType} color={car.color} />
        <span className="tag">{BODY_LABELS[car.bodyType]}</span>
        {car.safety.stars >= 4 && <span className="tag tag--safety">{car.safety.stars}★ NCAP</span>}
      </Link>
      <div className="car-card__body">
        <p className="eyebrow">{car.brand}</p>
        <h3 className="car-card__title">
          <Link to={`/cars/${car.slug}`}>{car.model}</Link>
        </h3>
        <p className="price">
          {priceRange(car.price)} <small>ex-showroom</small>
        </p>
        <ul className="spec-row">
          <li><GaugeIcon /> {headlineMileage(car)}</li>
          <li><FuelIcon /> {car.fuelTypes.join(' · ')}</li>
          <li><GearIcon /> {gearboxSummary(car)}</li>
          <li><SeatIcon /> {seatsText(car)}</li>
        </ul>
      </div>
      <div className="car-card__actions">
        <CompareToggle car={car} />
        <ShortlistButton car={car} />
        <Link to={`/cars/${car.slug}`} className="btn btn--small btn--ghost">
          Details
        </Link>
      </div>
    </article>
  );
}
