export default function ScoreRing({ score, size = 64 }) {
  const r = 26;
  const c = 2 * Math.PI * r;
  const tone = score >= 80 ? 'good' : score >= 65 ? 'ok' : 'warn';
  return (
    <div className={`score-ring score-ring--${tone}`} style={{ width: size, height: size }}>
      <svg viewBox="0 0 64 64" aria-hidden="true">
        <circle cx="32" cy="32" r={r} className="score-ring__track" />
        <circle cx="32" cy="32" r={r} className="score-ring__value" strokeDasharray={`${(score / 100) * c} ${c}`} />
      </svg>
      <span className="score-ring__text">
        {score}
        <small>%</small>
      </span>
      <span className="visually-hidden">Match score {score} out of 100</span>
    </div>
  );
}
