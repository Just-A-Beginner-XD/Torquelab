import { useEffect, useState } from 'react';
import { Link, NavLink, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import { useCompare } from '../context/CompareContext.jsx';
import { CloseIcon, MenuIcon } from './Icons.jsx';

export function Logo() {
  return (
    <Link to="/" className="logo" aria-label="Torque Lab home">
      <svg viewBox="0 0 32 32" width="30" height="30" aria-hidden="true">
        <rect width="32" height="32" rx="8" fill="currentColor" />
        <path d="M7 21a9 9 0 1 1 18 0" fill="none" stroke="#fff" strokeWidth="2.5" strokeLinecap="round" />
        <path d="M16 21l5-6" stroke="var(--accent)" strokeWidth="2.5" strokeLinecap="round" />
        <circle cx="16" cy="21" r="2" fill="var(--accent)" />
      </svg>
      <span>
        Torque<b>Lab</b>
      </span>
    </Link>
  );
}

export default function Navbar() {
  const { user, logout } = useAuth();
  const { items } = useCompare();
  const [open, setOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    setOpen(false);
  }, [location.pathname]);

  const onLogout = async () => {
    await logout();
    navigate('/');
  };

  return (
    <header className="navbar">
      <div className="container navbar__inner">
        <Logo />
        <button
          type="button"
          className="icon-btn navbar__toggle"
          onClick={() => setOpen((o) => !o)}
          aria-expanded={open}
          aria-controls="main-nav"
          aria-label={open ? 'Close menu' : 'Open menu'}
        >
          {open ? <CloseIcon size={22} /> : <MenuIcon size={22} />}
        </button>
        <nav id="main-nav" className={`navbar__nav ${open ? 'is-open' : ''}`} aria-label="Main">
          <NavLink to="/cars">Browse cars</NavLink>
          <NavLink to="/finder">Car Finder</NavLink>
          <NavLink to={items.length ? `/compare?cars=${items.map((i) => i.slug).join(',')}` : '/compare'} className={({ isActive }) => (isActive ? 'active' : '')}>
            Compare {items.length > 0 && <span className="badge">{items.length}</span>}
          </NavLink>
          <span className="navbar__divider" aria-hidden="true" />
          {user ? (
            <>
              <NavLink to="/garage">My Garage</NavLink>
              <span className="navbar__user" title={user.email}>
                Hi, {user.name.split(' ')[0]}
              </span>
              <button type="button" className="btn btn--small btn--outline" onClick={onLogout}>
                Log out
              </button>
            </>
          ) : (
            <>
              <NavLink to="/login">Log in</NavLink>
              <Link to="/signup" className="btn btn--small btn--primary">
                Sign up
              </Link>
            </>
          )}
        </nav>
      </div>
    </header>
  );
}
