import { Link, useLocation } from 'react-router-dom';
import { MAX_COMPARE, useCompare } from '../context/CompareContext.jsx';
import { CloseIcon, CompareIcon } from './Icons.jsx';

// Sticky tray listing the cars picked for comparison.
export default function CompareBar() {
  const { items, remove, clear, notice } = useCompare();
  const { pathname } = useLocation();
  if (pathname === '/compare' || (!items.length && !notice)) return null;

  const href = `/compare?cars=${items.map((i) => i.slug).join(',')}`;
  return (
    <aside className="compare-bar" aria-label="Cars selected for comparison">
      <div className="container compare-bar__inner">
        <div className="compare-bar__items">
          <span className="compare-bar__label">
            <CompareIcon /> Compare <strong>{items.length}/{MAX_COMPARE}</strong>
          </span>
          {items.map((i) => (
            <span key={i.slug} className="chip chip--removable">
              {i.name}
              <button type="button" onClick={() => remove(i.slug)} aria-label={`Remove ${i.name} from comparison`}>
                <CloseIcon size={14} />
              </button>
            </span>
          ))}
          {notice && <span className="compare-bar__notice" role="status">{notice}</span>}
        </div>
        <div className="compare-bar__actions">
          {items.length > 0 && (
            <button type="button" className="btn btn--small btn--ghost-light" onClick={clear}>
              Clear
            </button>
          )}
          {items.length >= 2 ? (
            <Link to={href} className="btn btn--small btn--primary">
              Compare now
            </Link>
          ) : (
            <span className="compare-bar__hint">Add {items.length ? 'one more car' : 'two cars'} to compare</span>
          )}
        </div>
      </div>
    </aside>
  );
}
