import { Component } from 'react';
import { reportProblem } from '../diagnostics.js';

// Without a boundary, an exception while rendering a page unmounts the whole app and leaves a blank screen.
// This shows a reload option instead, and reports the error so it can be fixed. It stays mounted while the
// visitor moves between pages (so it can also catch errors thrown while the old page is torn down) and
// clears itself when `resetKey` (the current path) changes.
export default class ErrorBoundary extends Component {
  state = { error: null };

  static getDerivedStateFromError(error) {
    return { error };
  }

  componentDidUpdate(prevProps) {
    if (this.state.error && prevProps.resetKey !== this.props.resetKey) this.setState({ error: null });
  }

  componentDidCatch(error, info) {
    reportProblem('render', error?.message || String(error), {
      stack: error?.stack?.slice(0, 2000),
      componentStack: info?.componentStack?.slice(0, 2000),
    });
  }

  render() {
    if (!this.state.error) return this.props.children;
    return (
      <div className="container page">
        <div className="empty">
          <h3>Something went wrong on this page</h3>
          <p>The problem has been reported. Reloading usually fixes it.</p>
          <button type="button" className="btn btn--primary" onClick={() => window.location.reload()}>
            Reload page
          </button>
        </div>
      </div>
    );
  }
}
