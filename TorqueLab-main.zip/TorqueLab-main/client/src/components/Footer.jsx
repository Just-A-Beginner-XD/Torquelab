import { Link } from 'react-router-dom';
import { Logo } from './Navbar.jsx';

export default function Footer() {
  return (
    <footer className="footer">
      <div className="container footer__inner">
        <div>
          <Logo />
          <p className="muted">Honest, explainable car recommendations for first-time buyers.</p>
        </div>
        <nav className="footer__links" aria-label="Footer">
          <Link to="/cars">Browse cars</Link>
          <Link to="/finder">Car Finder</Link>
          <Link to="/compare">Compare</Link>
          <Link to="/garage">My Garage</Link>
        </nav>
        <p className="footer__note">
          Prices are indicative ex-showroom figures and mileage is the claimed (ARAI) figure. This is sample data:
          always confirm with a dealer before you buy.
        </p>
      </div>
    </footer>
  );
}
