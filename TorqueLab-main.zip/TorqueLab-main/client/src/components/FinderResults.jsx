import { Link, useNavigate } from 'react-router-dom';
import { useCompare } from '../context/CompareContext.jsx';
import CarArt from './CarArt.jsx';
import CompareToggle from './CompareToggle.jsx';
import ScoreRing from './ScoreRing.jsx';
import ShortlistButton from './ShortlistButton.jsx';
import { AlertIcon, CheckIcon, CompareIcon } from './Icons.jsx';
import { EmptyState } from './States.jsx';
import { describeAnswers, FACTOR_LABELS } from '../finderOptions.js';
import { BODY_LABELS, priceRange, rupees } from '../format.js';

const verdictClass = (v) => `verdict verdict--${v.toLowerCase().replace(/\s+/g, '-')}`;
// "an SUV", "an MUV", "a Sedan": SUV and MUV are read letter by letter.
const withArticle = (label) => `${/^(SUV|MUV|[AEIOU])/.test(label) ? 'an' : 'a'} ${label}`;

function payback(o) {
  if (o.fuel === 'Petrol') return '—';
  if (o.paybackMonths == null) return 'Never at this usage';
  if (o.paybackMonths > 120) return '10+ years';
  if (o.paybackMonths < 12) return `${o.paybackMonths} months`;
  return `${(o.paybackMonths / 12).toFixed(1)} years`;
}

function BodyAdvice({ advice }) {
  const best = advice.ranked[0];
  const chosen = advice.chosen && advice.ranked.find((r) => r.type === advice.chosen);
  return (
    <section className="panel advice">
      <p className="eyebrow">Best body type for you</p>
      <h2 className="advice__title">
        <CarArt bodyType={best.type} color="#e8461e" /> {best.label}
      </h2>
      <ul className="reason-list reason-list--good">
        {best.reasons.slice(0, 3).map((r) => (
          <li key={r}><CheckIcon /> {r}</li>
        ))}
      </ul>
      {chosen && chosen.type !== best.type && (
        <p className="notice notice--warn">
          <AlertIcon /> You asked for {withArticle(chosen.label)}, so the results below are {chosen.label}s. Based on your other
          answers, {withArticle(best.label)} would suit you better.
        </p>
      )}
      <div className="body-bars">
        <p className="muted small">How each body type scores for you (tap one to see why):</p>
        {advice.ranked.map((r) => (
          <details key={r.type} className="body-bar">
            <summary>
              <span className="body-bar__label">{r.label}</span>
              <span className="bar" aria-hidden="true">
                <span style={{ width: `${r.score}%` }} />
              </span>
              <span className={verdictClass(r.verdict)}>{r.verdict}</span>
            </summary>
            <ul className="reason-list reason-list--compact">
              {r.reasons.map((t) => (
                <li key={t} className="is-good"><CheckIcon /> {t}</li>
              ))}
              {r.cautions.map((t) => (
                <li key={t} className="is-bad"><AlertIcon /> {t}</li>
              ))}
            </ul>
          </details>
        ))}
      </div>
    </section>
  );
}

function FuelAdvice({ advice }) {
  const { prices } = advice;
  return (
    <section className="panel advice">
      <p className="eyebrow">Suggested fuel</p>
      <h2 className="advice__title">{advice.recommended}</h2>
      <ul className="reason-list reason-list--good">
        {advice.reasons.map((r) => (
          <li key={r}><CheckIcon /> {r}</li>
        ))}
      </ul>
      <p className="tradeoff"><AlertIcon /> <span><strong>Trade-off:</strong> {advice.tradeoff}</span></p>
      {advice.note && <p className="notice notice--warn"><AlertIcon /> {advice.note}</p>}
      <div className="table-wrap">
        <table className="table table--compact">
          <caption>Fuel cost at about {advice.monthlyKm.toLocaleString('en-IN')} km a month</caption>
          <thead>
            <tr>
              <th scope="col">Fuel</th>
              <th scope="col">Per km</th>
              <th scope="col">Per month</th>
              <th scope="col">Extra upfront</th>
              <th scope="col">Pays back in</th>
            </tr>
          </thead>
          <tbody>
            {advice.options.map((o) => (
              <tr key={o.fuel} className={o.fuel === advice.recommended ? 'is-highlight' : ''}>
                <th scope="row">
                  {o.fuel}
                  {!o.available && <small className="muted"> above budget</small>}
                </th>
                <td>₹{o.costPerKm}</td>
                <td>{rupees(o.monthlyCost)}</td>
                <td>{o.premiumLakh ? `~₹${o.premiumLakh}L` : '—'}</td>
                <td>{payback(o)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="muted small">
        Assumes petrol ₹{prices.Petrol}/L, diesel ₹{prices.Diesel}/L, CNG ₹{prices.CNG}/kg, home charging at ₹
        {prices.Electric}/kWh and typical claimed efficiency. Extra upfront is the usual premium over a petrol version.
      </p>
    </section>
  );
}

function MatchCard({ match, rank }) {
  const { car, score, matchLabel, reasons, tradeoffs, misses, setup, breakdown } = match;
  const totalWeight = breakdown.reduce((sum, b) => sum + b.weight, 0);
  return (
    <li className={`match ${misses.length ? 'match--near' : ''}`}>
      <Link to={`/cars/${car.slug}`} className="match__media" style={{ '--car': car.color }} tabIndex={-1} aria-hidden="true">
        {rank && <span className="match__rank">#{rank}</span>}
        <CarArt bodyType={car.bodyType} color={car.color} />
      </Link>
      <div className="match__main">
        <div className="match__head">
          <div>
            <p className="eyebrow">{car.brand} · {BODY_LABELS[car.bodyType]}</p>
            <h3 className="match__title">
              <Link to={`/cars/${car.slug}`}>{car.model}</Link>
            </h3>
            <p className="price">{priceRange(car.price)} <small>ex-showroom</small></p>
          </div>
          <div className="match__score">
            <ScoreRing score={score} />
            <span className="match__label">{matchLabel}</span>
          </div>
        </div>

        {misses.length > 0 && (
          <ul className="chip-set" aria-label="Must-haves this car misses">
            {misses.map((m) => (
              <li key={m} className="chip chip--bad"><AlertIcon size={14} /> {m}</li>
            ))}
          </ul>
        )}

        <div className="match__why">
          <div>
            <h4>Why it fits</h4>
            <ul className="reason-list reason-list--good">
              {reasons.map((r) => (
                <li key={r}><CheckIcon /> {r}</li>
              ))}
            </ul>
          </div>
          <div>
            <h4>Trade-offs</h4>
            <ul className="reason-list reason-list--bad">
              {tradeoffs.map((t) => (
                <li key={t}><AlertIcon /> {t}</li>
              ))}
            </ul>
          </div>
        </div>

        <div className="match__setup">
          <span><strong>Our pick:</strong> {setup.text}</span>
          <span>
            <strong>Fuel cost:</strong> ≈ {rupees(setup.monthlyFuelCost)} a month{' '}
            <small className="muted">({setup.mileage.value} {setup.mileage.unit} claimed)</small>
          </span>
        </div>

        <details className="breakdown">
          <summary>How this score was calculated</summary>
          <ul className="breakdown__list">
            {breakdown.map((b) => (
              <li key={b.key}>
                <span>{FACTOR_LABELS[b.key] || b.key}</span>
                <span className="bar" aria-hidden="true">
                  <span style={{ width: `${b.score}%` }} />
                </span>
                <span className="breakdown__score">{b.score}</span>
                <small className="muted">{Math.round((b.weight / totalWeight) * 100)}% of score</small>
              </li>
            ))}
          </ul>
        </details>

        <div className="match__actions">
          <Link to={`/cars/${car.slug}`} className="btn btn--small btn--outline">View details</Link>
          <CompareToggle car={car} />
          <ShortlistButton car={car} />
        </div>
      </div>
    </li>
  );
}

export default function FinderResults({ result, onEdit, onRestart }) {
  const { replace } = useCompare();
  const navigate = useNavigate();
  const { answers, bodyAdvice, fuelAdvice, results, nearMatches, stats, saved } = result;

  const mustHaves = ['budget', 'seats'];
  if (answers.fuel !== 'any') mustHaves.push('fuel');
  if (answers.transmission !== 'any') mustHaves.push('gearbox');
  if (answers.bodyType !== 'any') mustHaves.push('body type');

  const compareTop = () => {
    const top = results.slice(0, 3).map((r) => r.car);
    replace(top);
    navigate(`/compare?cars=${top.map((c) => c.slug).join(',')}`);
  };

  return (
    <div className="container page">
      <header className="results-head">
        <div>
          <p className="eyebrow">Car Finder results</p>
          <h1>{results.length ? `Your top ${results.length} ${results.length === 1 ? 'match' : 'matches'}` : 'No exact matches yet'}</h1>
          <p className="muted">
            {stats.matching} of {stats.totalCars} cars meet all your must-haves ({mustHaves.join(', ')}).
          </p>
          <div className="chip-set">
            {describeAnswers(answers).map((c) => (
              <span key={c} className="chip">{c}</span>
            ))}
          </div>
        </div>
        <div className="results-head__actions">
          {results.length >= 2 && (
            <button type="button" className="btn btn--primary" onClick={compareTop}>
              <CompareIcon /> Compare top {Math.min(3, results.length)}
            </button>
          )}
          <button type="button" className="btn btn--outline" onClick={onEdit}>Edit answers</button>
          <button type="button" className="btn btn--ghost" onClick={onRestart}>Start over</button>
        </div>
      </header>

      {saved ? (
        <p className="notice notice--good"><CheckIcon /> Saved to your garage. Next time, the Car Finder starts with these answers.</p>
      ) : (
        <p className="notice">
          <span>
            Want to keep these answers? <Link to="/signup" state={{ from: { pathname: '/finder' } }}>Create a free account</Link> or{' '}
            <Link to="/login" state={{ from: { pathname: '/finder' } }}>log in</Link> and we’ll save them to your garage.
          </span>
        </p>
      )}

      <div className="advice-grid">
        <BodyAdvice advice={bodyAdvice} />
        <FuelAdvice advice={fuelAdvice} />
      </div>

      <section className="section">
        <h2>Recommended cars</h2>
        {results.length === 0 ? (
          <EmptyState title="No car meets every must-have">
            Your combination of budget and requirements is hard to meet. The closest alternatives are below. Try raising
            your budget or relaxing a preference.
          </EmptyState>
        ) : (
          <ol className="match-list">
            {results.map((m, i) => (
              <MatchCard key={m.car.slug} match={m} rank={i + 1} />
            ))}
          </ol>
        )}
      </section>

      {nearMatches.length > 0 && (
        <section className="section">
          <h2>Close, but not a perfect fit</h2>
          <p className="muted">These cars miss at least one of your must-haves, shown in red.</p>
          <ol className="match-list">
            {nearMatches.map((m) => (
              <MatchCard key={m.car.slug} match={m} />
            ))}
          </ol>
        </section>
      )}
    </div>
  );
}
