import { useCompare } from '../context/CompareContext.jsx';
import { CheckIcon, CompareIcon } from './Icons.jsx';

export default function CompareToggle({ car, variant = 'check' }) {
  const { has, toggle } = useCompare();
  const active = has(car.slug);

  if (variant === 'button') {
    return (
      <button type="button" className={`btn btn--outline ${active ? 'is-active' : ''}`} onClick={() => toggle(car)} aria-pressed={active}>
        {active ? <CheckIcon /> : <CompareIcon />}
        <span>{active ? 'Added to compare' : 'Add to compare'}</span>
      </button>
    );
  }
  return (
    <label className="compare-check">
      <input type="checkbox" checked={active} onChange={() => toggle(car)} />
      <span>Compare</span>
    </label>
  );
}
