// Radio or checkbox choices rendered as selectable cards. Uses real inputs so keyboard
// navigation and screen readers work without extra code.
export default function OptionGroup({ legend, name, options, value, onChange, multiple = false, max, columns = 2, hint }) {
  const selected = (v) => (multiple ? value.includes(v) : value === v);

  const handle = (v) => {
    if (!multiple) return onChange(v);
    if (value.includes(v)) return onChange(value.filter((x) => x !== v));
    if (max && value.length >= max) return undefined;
    return onChange([...value, v]);
  };

  return (
    <fieldset className="option-group">
      <legend>{legend}</legend>
      {hint && <p className="option-group__hint">{hint}</p>}
      <div className={`option-grid option-grid--${columns}`}>
        {options.map((o) => {
          const disabled = multiple && max && !selected(o.value) && value.length >= max;
          return (
            <label key={String(o.value)} className={`option ${selected(o.value) ? 'is-selected' : ''} ${disabled ? 'is-disabled' : ''}`}>
              <input
                type={multiple ? 'checkbox' : 'radio'}
                name={name}
                checked={selected(o.value)}
                disabled={disabled}
                onChange={() => handle(o.value)}
              />
              {o.icon && <span className="option__icon">{o.icon}</span>}
              <span className="option__label">{o.label}</span>
              {o.hint && <span className="option__hint">{o.hint}</span>}
            </label>
          );
        })}
      </div>
    </fieldset>
  );
}
