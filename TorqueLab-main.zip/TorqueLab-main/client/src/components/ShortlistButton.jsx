import { useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import { HeartIcon } from './Icons.jsx';

// Saves a car to the signed-in user's garage. Guests are sent to log in first.
export default function ShortlistButton({ car, withLabel = false }) {
  const { user, shortlist, toggleShortlist } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const saved = shortlist.has(car.slug);

  const onClick = () => {
    if (!user) {
      navigate('/login', { state: { from: location, message: 'Log in to save cars to your garage.' } });
      return;
    }
    toggleShortlist(car.slug);
  };

  const label = saved ? `Remove ${car.name} from your garage` : `Save ${car.name} to your garage`;
  return (
    <button
      type="button"
      className={`btn ${withLabel ? 'btn--outline' : 'icon-btn'} shortlist-btn ${saved ? 'is-saved' : ''}`}
      onClick={onClick}
      aria-pressed={saved}
      aria-label={withLabel ? undefined : label}
      title={label}
    >
      <HeartIcon filled={saved} />
      {withLabel && <span>{saved ? 'Saved' : 'Save'}</span>}
    </button>
  );
}
