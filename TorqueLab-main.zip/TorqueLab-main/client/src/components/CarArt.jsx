// Side-profile illustration of a car, drawn per body type and tinted with the car's colour.
// Using drawings instead of photos keeps the project free of licensed imagery.

const SHAPES = {
  hatchback: {
    body: 'M44 108 L42 84 Q42 72 48 64 L58 46 Q62 38 74 37 L156 35 Q168 35 178 43 L202 64 L250 70 Q274 74 278 86 L280 104 Q280 108 274 108 L250 108 A24 24 0 0 0 202 108 L120 108 A24 24 0 0 0 72 108 Z',
    glass: 'M60 64 L68 47 Q72 42 80 42 L154 41 Q162 41 169 47 L190 64 Z',
    pillars: [120],
    wheels: [96, 226],
    wheelY: 106,
    r: 19,
    sill: 108,
    arch: 24,
    head: 'M262 78 L277 82 L277 88 L265 86 Z',
    tail: 'M42 70 L50 68 L50 80 L42 80 Z',
  },
  sedan: {
    body: 'M18 106 L16 88 Q16 80 24 78 L62 74 Q76 72 88 62 L112 44 Q120 38 132 38 L186 38 Q196 38 204 46 L228 68 L272 74 Q296 78 300 90 L300 102 Q300 106 294 106 L266 106 A24 24 0 0 0 218 106 L108 106 A24 24 0 0 0 60 106 Z',
    glass: 'M92 70 L116 49 Q122 44 132 44 L184 44 Q192 44 198 50 L218 70 Z',
    pillars: [152],
    wheels: [84, 242],
    wheelY: 104,
    r: 19,
    sill: 106,
    arch: 24,
    head: 'M282 80 L298 86 L298 92 L284 90 Z',
    tail: 'M16 82 L26 80 L26 90 L16 90 Z',
  },
  suv: {
    body: 'M22 100 L20 70 Q20 58 26 52 L34 34 Q38 26 50 25 L192 24 Q204 24 212 32 L232 56 L276 60 Q298 62 300 76 L300 96 Q300 100 294 100 L268 100 A26 26 0 0 0 216 100 L112 100 A26 26 0 0 0 60 100 Z',
    glass: 'M32 56 L40 36 Q43 31 50 31 L190 30 Q198 30 204 36 L224 56 Z',
    pillars: [92, 150],
    wheels: [86, 242],
    wheelY: 101,
    r: 21,
    sill: 100,
    arch: 26,
    head: 'M282 66 L299 70 L299 78 L284 76 Z',
    tail: 'M20 60 L28 58 L28 74 L20 74 Z',
    cladding: 'M22 92 L60 92 M112 92 L216 92 M268 92 L300 92',
    rails: 'M60 21 L184 20',
  },
  muv: {
    body: 'M18 104 L16 74 Q16 60 22 52 L28 36 Q32 28 44 27 L188 26 Q200 26 208 34 L240 62 L278 68 Q298 72 300 86 L300 100 Q300 104 294 104 L262 104 A25 25 0 0 0 212 104 L110 104 A25 25 0 0 0 58 104 Z',
    glass: 'M28 56 L34 38 Q37 33 44 33 L186 32 Q196 32 202 38 L228 60 Z',
    pillars: [84, 140],
    wheels: [84, 237],
    wheelY: 104,
    r: 20,
    sill: 104,
    arch: 25,
    head: 'M284 76 L299 80 L299 88 L286 86 Z',
    tail: 'M16 62 L24 60 L24 76 L16 76 Z',
  },
};

export default function CarArt({ bodyType = 'hatchback', color = '#e8461e', label, className = '' }) {
  const type = SHAPES[bodyType] ? bodyType : 'hatchback';
  const s = SHAPES[type];
  const clipId = `car-glass-clip-${type}`;
  return (
    <svg
      className={`car-art ${className}`}
      viewBox="0 0 320 136"
      role={label ? 'img' : undefined}
      aria-label={label}
      aria-hidden={label ? undefined : true}
    >
      <ellipse cx="160" cy="126" rx="146" ry="6" fill="currentColor" opacity="0.12" />
      {s.rails && <path d={s.rails} stroke="#1c2330" strokeWidth="3" strokeLinecap="round" opacity="0.65" />}
      {s.wheels.map((cx) => (
        <path key={cx} d={`M${cx - s.arch} ${s.sill} A${s.arch} ${s.arch} 0 0 1 ${cx + s.arch} ${s.sill} Z`} fill="#0d1118" />
      ))}
      <path d={s.body} fill={color} />
      <path d={s.body} fill="url(#car-shine)" />
      <path d={s.glass} fill="#1b2433" opacity="0.88" />
      <path d={s.glass} fill="url(#car-glass)" />
      <g clipPath={`url(#${clipId})`}>
        {s.pillars.map((x) => (
          <rect key={x} x={x} y="20" width="6" height="60" fill={color} />
        ))}
      </g>
      <path d={s.glass} fill="none" stroke={color} strokeWidth="2" />
      {s.cladding && <path d={s.cladding} stroke="#1c2330" strokeWidth="8" opacity="0.55" />}
      <path d={s.head} fill="#fff6d8" />
      <path d={s.tail} fill="#c81e1e" opacity="0.9" />
      {s.wheels.map((cx) => (
        <g key={cx}>
          <circle cx={cx} cy={s.wheelY} r={s.r} fill="#161b24" />
          <circle cx={cx} cy={s.wheelY} r={s.r * 0.58} fill="#c9ced8" />
          <circle cx={cx} cy={s.wheelY} r={s.r * 0.22} fill="#6b7280" />
        </g>
      ))}
      <defs>
        <clipPath id={clipId}>
          <path d={s.glass} />
        </clipPath>
        <linearGradient id="car-shine" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#fff" stopOpacity="0.35" />
          <stop offset="0.45" stopColor="#fff" stopOpacity="0" />
          <stop offset="1" stopColor="#000" stopOpacity="0.22" />
        </linearGradient>
        <linearGradient id="car-glass" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#fff" stopOpacity="0.28" />
          <stop offset="0.5" stopColor="#fff" stopOpacity="0" />
        </linearGradient>
      </defs>
    </svg>
  );
}
