// Reports problems that happen in the visitor's browser to the server (stored in the client_errors table),
// so issues on other devices can be diagnosed. Each distinct problem is sent once per page load.
const sent = new Set();

export function reportProblem(kind, message, detail = null) {
  const key = `${kind}:${message}`;
  if (sent.has(key) || sent.size >= 20) return;
  sent.add(key);
  const body = JSON.stringify({ kind, message: String(message).slice(0, 1000), url: location.href, detail });
  try {
    if (navigator.sendBeacon?.('/api/client-errors', new Blob([body], { type: 'application/json' }))) return;
  } catch {
    /* fall back to fetch */
  }
  fetch('/api/client-errors', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body, keepalive: true }).catch(() => {});
}

export function installGlobalErrorReporting() {
  window.addEventListener('error', (event) => {
    if (!event.message) return; // resource load errors are handled by the inline script in index.html
    reportProblem('js-error', event.message, {
      source: event.filename,
      line: event.lineno,
      column: event.colno,
      stack: event.error?.stack?.slice(0, 2000),
    });
  });
  window.addEventListener('unhandledrejection', (event) => {
    const reason = event.reason;
    reportProblem('promise', reason?.message || String(reason), { stack: reason?.stack?.slice(0, 2000) });
  });
}
