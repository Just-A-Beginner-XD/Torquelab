export const BODY_LABELS = { hatchback: 'Hatchback', sedan: 'Sedan', suv: 'SUV', muv: 'MUV' };

const num = (n) => (Number.isInteger(n) ? String(n) : n.toFixed(2));

export function priceRange({ min, max }) {
  return min === max ? `₹${num(min)} Lakh` : `₹${num(min)} – ${num(max)} Lakh`;
}

export const lakh = (n) => `₹${num(n)} Lakh`;
export const rupees = (n) => `₹${Math.round(n).toLocaleString('en-IN')}`;

export function range([a, b], unit) {
  return a === b ? `${a} ${unit}` : `${a}–${b} ${unit}`;
}

export const mileageUnit = (fuel) => ({ CNG: 'km/kg', Electric: 'km range' })[fuel] || 'km/l';

export const isElectric = (car) => car.fuelTypes.length === 1 && car.fuelTypes[0] === 'Electric';

// Headline efficiency for cards: the best km/l range, e.g. "24.8–25.75 km/l", or the claimed range for EVs.
export function headlineMileage(car) {
  const liquid = car.fuelTypes.filter((f) => f !== 'CNG' && f !== 'Electric');
  const fuel = liquid.length
    ? liquid.reduce((x, y) => (car.mileage[y][1] > car.mileage[x][1] ? y : x))
    : car.fuelTypes[0];
  return range(car.mileage[fuel], mileageUnit(fuel));
}

export function gearboxSummary(car) {
  const manual = car.transmissions.includes('Manual');
  if (manual && car.hasAutomatic) return 'Manual & Auto';
  return manual ? 'Manual' : 'Automatic';
}

export const seatsText = (car) => `${car.seating.join(' / ')} seats`;

export function displacement(car) {
  if (!car.displacementCc) {
    const { min, max } = car.batteryKwh;
    return min === max ? `${min} kWh battery` : `${min}–${max} kWh battery`;
  }
  const { min, max } = car.displacementCc;
  return min === max ? `${min} cc` : `${min}–${max} cc`;
}

export const bootText = (litres) => (litres > 0 ? `${litres} L` : 'Minimal');

export function ncapText(safety) {
  return safety.stars ? `${safety.stars}-star ${safety.agency}` : 'Not rated yet';
}
