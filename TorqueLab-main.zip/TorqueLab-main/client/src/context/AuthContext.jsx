import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { api } from '../api.js';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [ready, setReady] = useState(false);
  const [shortlist, setShortlist] = useState(() => new Set());
  const [shortlistReady, setShortlistReady] = useState(false);

  useEffect(() => {
    api('/auth/me')
      .then((d) => setUser(d.user))
      .catch(() => setUser(null))
      .finally(() => setReady(true));
  }, []);

  useEffect(() => {
    setShortlistReady(false);
    if (!user) {
      setShortlist(new Set());
      return;
    }
    api('/me/shortlist')
      .then((d) => setShortlist(new Set(d.cars.map((c) => c.slug))))
      .catch(() => {})
      .finally(() => setShortlistReady(true));
  }, [user]);

  const login = useCallback(async (email, password) => {
    const d = await api('/auth/login', { method: 'POST', body: { email, password } });
    setUser(d.user);
    return d.user;
  }, []);

  const signup = useCallback(async (name, email, password) => {
    const d = await api('/auth/signup', { method: 'POST', body: { name, email, password } });
    setUser(d.user);
    return d.user;
  }, []);

  const logout = useCallback(async () => {
    await api('/auth/logout', { method: 'POST' }).catch(() => {});
    setUser(null);
  }, []);

  const toggleShortlist = useCallback(
    async (slug) => {
      const saved = shortlist.has(slug);
      const update = (add) =>
        setShortlist((prev) => {
          const next = new Set(prev);
          if (add) next.add(slug);
          else next.delete(slug);
          return next;
        });
      update(!saved); // optimistic
      try {
        await api(`/me/shortlist/${slug}`, { method: saved ? 'DELETE' : 'PUT' });
      } catch {
        update(saved);
      }
    },
    [shortlist],
  );

  const value = useMemo(
    () => ({ user, ready, login, signup, logout, shortlist, shortlistReady, toggleShortlist }),
    [user, ready, login, signup, logout, shortlist, shortlistReady, toggleShortlist],
  );
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export const useAuth = () => useContext(AuthContext);
