import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';

export const MAX_COMPARE = 3;
const STORAGE_KEY = 'torque-lab:compare';

const CompareContext = createContext(null);

function load() {
  try {
    const items = JSON.parse(localStorage.getItem(STORAGE_KEY));
    return Array.isArray(items) ? items.slice(0, MAX_COMPARE) : [];
  } catch {
    return [];
  }
}

// Holds up to three cars ({ slug, name }) picked for side-by-side comparison.
export function CompareProvider({ children }) {
  const [items, setItems] = useState(load);
  const [notice, setNotice] = useState(null);
  const timer = useRef();

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
    } catch {
      /* storage unavailable: comparison still works for this visit */
    }
  }, [items]);

  const flash = useCallback((message) => {
    setNotice(message);
    clearTimeout(timer.current);
    timer.current = setTimeout(() => setNotice(null), 3500);
  }, []);

  const has = useCallback((slug) => items.some((i) => i.slug === slug), [items]);

  const toggle = useCallback(
    (car) => {
      if (items.some((i) => i.slug === car.slug)) {
        setItems(items.filter((i) => i.slug !== car.slug));
      } else if (items.length >= MAX_COMPARE) {
        flash(`You can compare up to ${MAX_COMPARE} cars. Remove one first.`);
      } else {
        setItems([...items, { slug: car.slug, name: car.name }]);
      }
    },
    [items, flash],
  );

  const remove = useCallback((slug) => setItems((list) => list.filter((i) => i.slug !== slug)), []);
  const clear = useCallback(() => setItems([]), []);
  const replace = useCallback(
    (cars) => setItems(cars.slice(0, MAX_COMPARE).map((c) => ({ slug: c.slug, name: c.name }))),
    [],
  );

  const value = useMemo(
    () => ({ items, has, toggle, remove, clear, replace, notice }),
    [items, has, toggle, remove, clear, replace, notice],
  );
  return <CompareContext.Provider value={value}>{children}</CompareContext.Provider>;
}

export const useCompare = () => useContext(CompareContext);
