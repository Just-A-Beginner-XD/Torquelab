import { useCallback, useEffect, useState } from 'react';
import { reportProblem } from './diagnostics.js';

export class ApiError extends Error {
  constructor(message, status, body) {
    super(message);
    this.status = status;
    this.body = body;
  }
}

const TIMEOUT_MS = 25000;
const SLOW_MS = 8000;

export async function api(path, { method = 'GET', body } = {}) {
  // Give up after a while so a stalled request shows an error with a retry button, not an endless spinner.
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
  const started = Date.now();
  let res;
  try {
    res = await fetch(`/api${path}`, {
      method,
      headers: body ? { 'Content-Type': 'application/json' } : undefined,
      body: body ? JSON.stringify(body) : undefined,
      credentials: 'same-origin',
      signal: controller.signal,
    });
  } catch (err) {
    clearTimeout(timer);
    reportProblem('api-failed', `${method} /api${path}: ${err.name === 'AbortError' ? 'timed out' : 'network error'}`, {
      error: String(err?.message || err),
      ms: Date.now() - started,
      online: navigator.onLine,
    });
    throw new ApiError(
      err.name === 'AbortError'
        ? 'The server is taking too long to respond. Please try again.'
        : 'Cannot reach the server. Check your connection and try again.',
      0,
      null,
    );
  }
  clearTimeout(timer);
  const ms = Date.now() - started;
  if (ms > SLOW_MS) reportProblem('api-slow', `${method} /api${path} took ${ms} ms`, { status: res.status });
  if (res.status >= 500) reportProblem('api-failed', `${method} /api${path}: HTTP ${res.status}`, { ms });
  if (res.status === 204) return null;
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new ApiError(data.error || 'Something went wrong.', res.status, data);
  return data;
}

// Fetches `path` whenever it changes. Pass null to skip fetching.
export function useApi(path) {
  const [state, setState] = useState({ data: null, error: null, loading: Boolean(path) });
  const [nonce, setNonce] = useState(0);

  useEffect(() => {
    if (!path) {
      setState({ data: null, error: null, loading: false });
      return undefined;
    }
    let cancelled = false;
    setState((s) => ({ ...s, loading: true, error: null }));
    api(path)
      .then((data) => !cancelled && setState({ data, error: null, loading: false }))
      .catch((error) => !cancelled && setState({ data: null, error, loading: false }));
    return () => {
      cancelled = true;
    };
  }, [path, nonce]);

  const reload = useCallback(() => setNonce((n) => n + 1), []);
  return { ...state, reload };
}
