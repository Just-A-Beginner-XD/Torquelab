// Questions and answer choices for the Car Finder. Values match what the API expects.

export const DEFAULT_ANSWERS = {
  budget: 10,
  familySize: 4,
  newDriver: false,
  dailyKm: 35,
  conditions: 'mixed',
  mileagePref: 'any',
  fuel: 'any',
  transmission: 'any',
  bodyType: 'any',
  priorities: [],
};

export const BUDGET_PRESETS = [5, 8, 10, 12, 15, 20, 30];

export const FAMILY_OPTIONS = [
  { value: 2, label: '1–2 people', hint: 'Just me, or me and a partner' },
  { value: 4, label: '3–4 people', hint: 'A small family' },
  { value: 5, label: '5 people', hint: 'Full rear seat most days' },
  { value: 7, label: '6–7 people', hint: 'Joint family or carpool' },
];

export const DAILY_KM_OPTIONS = [
  { value: 15, label: 'Under 20 km', hint: 'Short errands and school runs' },
  { value: 35, label: '20–50 km', hint: 'A typical city commute' },
  { value: 75, label: '50–100 km', hint: 'A long daily commute' },
  { value: 120, label: '100+ km', hint: 'Heavy daily use or work travel' },
];

export const CONDITION_OPTIONS = [
  { value: 'city', label: 'City traffic', hint: 'Stop-and-go, tight parking' },
  { value: 'highway', label: 'Highways', hint: 'Long, fast stretches' },
  { value: 'mixed', label: 'A mix of both', hint: 'City on weekdays, trips on weekends' },
  { value: 'rough', label: 'Rough or rural roads', hint: 'Potholes, speed breakers, unpaved' },
];

export const MILEAGE_OPTIONS = [
  { value: 'any', label: 'Doesn’t matter' },
  { value: '12-15', label: '12–15 km/l' },
  { value: '15-20', label: '15–20 km/l' },
  { value: '20+', label: '20+ km/l' },
];

export const FUEL_OPTIONS = [
  { value: 'any', label: 'Suggest one', hint: 'We’ll do the maths' },
  { value: 'Petrol', label: 'Petrol' },
  { value: 'Diesel', label: 'Diesel' },
  { value: 'CNG', label: 'CNG' },
  { value: 'Hybrid', label: 'Hybrid' },
  { value: 'Electric', label: 'Electric' },
];

export const TRANSMISSION_OPTIONS = [
  { value: 'any', label: 'No preference' },
  { value: 'manual', label: 'Manual', hint: 'Cheaper, more control' },
  { value: 'automatic', label: 'Automatic', hint: 'Easier in traffic' },
];

export const BODY_OPTIONS = [
  { value: 'any', label: 'Help me decide', hint: 'Recommended' },
  { value: 'hatchback', label: 'Hatchback' },
  { value: 'sedan', label: 'Sedan' },
  { value: 'suv', label: 'SUV' },
  { value: 'muv', label: 'MUV / 7-seater' },
];

export const PRIORITY_OPTIONS = [
  { value: 'safety', label: 'Safety' },
  { value: 'space', label: 'Space & boot' },
  { value: 'performance', label: 'Performance' },
  { value: 'comfort', label: 'Comfort & features' },
  { value: 'low-maintenance', label: 'Low maintenance' },
];

export const FACTOR_LABELS = {
  budget: 'Budget fit',
  space: 'Seats & space',
  mileage: 'Claimed mileage',
  runningCost: 'Running cost',
  conditions: 'Suits your roads',
  safety: 'Safety',
  body: 'Body type',
  newDriver: 'New-driver friendly',
  performance: 'Performance',
  comfort: 'Comfort & features',
  ownership: 'Ease of ownership',
};

const labelOf = (options, value) => options.find((o) => o.value === value)?.label;

// Short, human-readable chips describing a set of answers.
export function describeAnswers(a) {
  const chips = [
    `Up to ₹${a.budget} Lakh`,
    labelOf(FAMILY_OPTIONS, a.familySize) || `${a.familySize} people`,
    labelOf(DAILY_KM_OPTIONS, a.dailyKm) ? `${labelOf(DAILY_KM_OPTIONS, a.dailyKm)} a day` : `${a.dailyKm} km a day`,
    labelOf(CONDITION_OPTIONS, a.conditions),
  ];
  if (a.newDriver) chips.push('New driver');
  if (a.mileagePref !== 'any') chips.push(`Mileage ${labelOf(MILEAGE_OPTIONS, a.mileagePref)}`);
  if (a.fuel !== 'any') chips.push(a.fuel);
  if (a.transmission !== 'any') chips.push(labelOf(TRANSMISSION_OPTIONS, a.transmission));
  if (a.bodyType !== 'any') chips.push(labelOf(BODY_OPTIONS, a.bodyType));
  for (const p of a.priorities || []) chips.push(labelOf(PRIORITY_OPTIONS, p));
  return chips.filter(Boolean);
}
