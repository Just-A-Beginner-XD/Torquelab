import { useEffect } from 'react';
import { Route, Routes, useLocation } from 'react-router-dom';
import Navbar from './components/Navbar.jsx';
import Footer from './components/Footer.jsx';
import CompareBar from './components/CompareBar.jsx';
import RequireAuth from './components/RequireAuth.jsx';
import ErrorBoundary from './components/ErrorBoundary.jsx';
import HomePage from './pages/HomePage.jsx';
import CarsPage from './pages/CarsPage.jsx';
import CarDetailPage from './pages/CarDetailPage.jsx';
import FinderPage from './pages/FinderPage.jsx';
import ComparePage from './pages/ComparePage.jsx';
import { LoginPage, SignupPage } from './pages/AuthPages.jsx';
import GaragePage from './pages/GaragePage.jsx';
import NotFoundPage from './pages/NotFoundPage.jsx';

function ScrollToTop() {
  const { pathname } = useLocation();
  // Braces matter: an effect's return value is treated as its cleanup function. Newer Chrome versions make
  // window.scrollTo() return a Promise, and returning it here crashed the app on the next page change.
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
}

export default function App() {
  const { pathname } = useLocation();
  return (
    <div className="app">
      <ScrollToTop />
      <a className="skip-link" href="#main">
        Skip to content
      </a>
      <Navbar />
      <main id="main">
        <ErrorBoundary resetKey={pathname}>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/cars" element={<CarsPage />} />
            <Route path="/cars/:slug" element={<CarDetailPage />} />
            <Route path="/finder" element={<FinderPage />} />
            <Route path="/compare" element={<ComparePage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/signup" element={<SignupPage />} />
            <Route
              path="/garage"
              element={
                <RequireAuth>
                  <GaragePage />
                </RequireAuth>
              }
            />
            <Route path="*" element={<NotFoundPage />} />
          </Routes>
        </ErrorBoundary>
      </main>
      <Footer />
      <CompareBar />
    </div>
  );
}
