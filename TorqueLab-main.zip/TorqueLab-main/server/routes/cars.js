import { Router } from 'express';
import { BODY_LABELS, BODY_TYPES, FUELS, filterCars } from '../lib/cars.js';
import { matchModel } from '../lib/nhtsa.js';

export function carRoutes(pool, carRepo, nhtsa) {
  const router = Router();

  router.get('/', async (req, res) => {
    const cars = filterCars(await carRepo.all(), req.query);
    res.json({ cars, total: cars.length });
  });

  // Facts the UI needs to build filters and home-page tiles.
  router.get('/meta', async (_req, res) => {
    const cars = await carRepo.all();
    const count = (pred) => cars.filter(pred).length;
    const brands = [...new Set(cars.map((c) => c.brand))]
      .sort()
      .map((name) => ({ name, count: count((c) => c.brand === name) }));
    res.json({
      total: cars.length,
      brands,
      bodyTypes: BODY_TYPES.map((type) => ({ type, label: BODY_LABELS[type], count: count((c) => c.bodyType === type) })),
      fuels: FUELS.map((fuel) => ({ fuel, count: count((c) => c.fuelTypes.includes(fuel)) })),
      price: {
        min: Math.min(...cars.map((c) => c.price.min)),
        max: Math.max(...cars.map((c) => c.price.max)),
      },
    });
  });

  router.get('/:slug', async (req, res) => {
    const all = await carRepo.all();
    const car = all.find((c) => c.slug === req.params.slug);
    if (!car) return res.status(404).json({ error: 'Car not found.' });

    // "Similar cars": same body type and powertrain family (electric or not) first, then closest starting price.
    const isEv = (c) => c.fuelTypes.includes('Electric');
    const similar = all
      .filter((c) => c.slug !== car.slug)
      .map((c) => ({
        c,
        distance: Math.abs(c.price.min - car.price.min) + (c.bodyType === car.bodyType ? 0 : 6) + (isEv(c) === isEv(car) ? 0 : 5),
      }))
      .sort((a, b) => a.distance - b.distance)
      .slice(0, 3)
      .map(({ c }) => c);

    res.json({ car, similar });
  });

  // Live global line-up for the car's brand, from the NHTSA vehicle database.
  router.get('/:slug/global', async (req, res) => {
    const car = await carRepo.bySlug(req.params.slug);
    if (!car) return res.status(404).json({ error: 'Car not found.' });

    const [[brand]] = await pool.query('SELECT nhtsa_make FROM brands WHERE name = ?', [car.brand]);
    if (!brand?.nhtsa_make) {
      return res.json({
        available: false,
        reason: `${car.brand} does not sell cars in the US, so the NHTSA vehicle database has no line-up for it.`,
      });
    }
    try {
      const lineup = await nhtsa.brandLineup(brand.nhtsa_make);
      res.json({ available: true, source: 'NHTSA vPIC', ...lineup, match: matchModel(car.model, lineup.models) });
    } catch (err) {
      console.warn(`[nhtsa] ${brand.nhtsa_make}: ${err.message}`);
      res.status(502).json({ error: 'The live NHTSA vehicle database could not be reached right now. Try again later.' });
    }
  });

  return router;
}
