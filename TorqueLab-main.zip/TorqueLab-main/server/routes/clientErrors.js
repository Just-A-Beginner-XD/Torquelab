import { Router } from 'express';

const MAX_PER_MINUTE = 30;
const KEEP_DAYS = 30;
const clip = (value, length) => String(value ?? '').slice(0, length);

// Lets browsers report problems the server can't see — a page that never rendered, a JavaScript crash,
// a failed request — so issues on visitors' devices can be diagnosed from the `client_errors` table
// or the server logs.
export function clientErrorRoutes(pool) {
  const router = Router();
  const hits = new Map(); // visitor ip -> { minute, count }

  router.post('/', async (req, res) => {
    const ip = req.get('cf-connecting-ip') || req.ip;
    const minute = Math.floor(Date.now() / 60000);
    const seen = hits.get(ip);
    const count = seen?.minute === minute ? seen.count + 1 : 1;
    if (count > MAX_PER_MINUTE) return res.status(429).end();
    if (hits.size > 10000) hits.clear();
    hits.set(ip, { minute, count });

    const body = req.body || {};
    let detail = JSON.stringify(body.detail ?? null);
    if (detail.length > 8000) detail = JSON.stringify({ truncated: detail.slice(0, 7000) });
    const row = [clip(body.kind, 30) || 'unknown', clip(body.message, 1000), clip(body.url, 500), clip(req.get('user-agent'), 400), detail];

    console.warn(`[client-error] ${row[0]}: ${row[1]} | ${row[2]} | ${row[3]}`);
    await pool.query('INSERT INTO client_errors (kind, message, page_url, user_agent, detail) VALUES (?, ?, ?, ?, ?)', row);
    if (Math.random() < 0.02) {
      await pool.query('DELETE FROM client_errors WHERE created_at < NOW() - INTERVAL ? DAY', [KEEP_DAYS]);
    }
    res.status(204).end();
  });

  return router;
}
