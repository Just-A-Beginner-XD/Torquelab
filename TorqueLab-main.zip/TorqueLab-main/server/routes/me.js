import { Router } from 'express';
import { requireAuth } from '../middleware/auth.js';

// Routes for the signed-in user's garage: shortlisted cars and saved Car Finder answers.
export function meRoutes(pool, carRepo) {
  const router = Router();
  router.use(requireAuth);

  router.get('/shortlist', async (req, res) => {
    const [rows] = await pool.query('SELECT car_id FROM shortlists WHERE user_id = ? ORDER BY created_at DESC', [req.userId]);
    const byId = new Map((await carRepo.all()).map((c) => [c.id, c]));
    res.json({ cars: rows.map((r) => byId.get(r.car_id)).filter(Boolean) });
  });

  router.put('/shortlist/:slug', async (req, res) => {
    const car = await carRepo.bySlug(req.params.slug);
    if (!car) return res.status(404).json({ error: 'Car not found.' });
    await pool.query('INSERT IGNORE INTO shortlists (user_id, car_id) VALUES (?, ?)', [req.userId, car.id]);
    res.status(204).end();
  });

  router.delete('/shortlist/:slug', async (req, res) => {
    const car = await carRepo.bySlug(req.params.slug);
    if (car) await pool.query('DELETE FROM shortlists WHERE user_id = ? AND car_id = ?', [req.userId, car.id]);
    res.status(204).end();
  });

  router.get('/preferences', async (req, res) => {
    const [[row]] = await pool.query('SELECT answers FROM user_preferences WHERE user_id = ?', [req.userId]);
    res.json({ preferences: row?.answers ?? null });
  });

  return router;
}
