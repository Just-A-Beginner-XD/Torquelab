import { Router } from 'express';
import bcrypt from 'bcryptjs';
import { clearAuthCookie, optionalAuth, setAuthCookie } from '../middleware/auth.js';

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const publicUser = (row) => ({ id: row.id, name: row.name, email: row.email });

export function authRoutes(pool) {
  const router = Router();
  const findByEmail = async (email) => (await pool.query('SELECT * FROM users WHERE email = ?', [email]))[0][0];
  const findById = async (id) => (await pool.query('SELECT * FROM users WHERE id = ?', [id]))[0][0];

  router.post('/signup', async (req, res) => {
    const name = String(req.body?.name || '').trim();
    const email = String(req.body?.email || '').trim().toLowerCase();
    const password = String(req.body?.password || '');

    const errors = {};
    if (name.length < 2 || name.length > 100) errors.name = 'Please enter your name.';
    if (!EMAIL_RE.test(email) || email.length > 191) errors.email = 'Please enter a valid email address.';
    if (password.length < 8) errors.password = 'Password must be at least 8 characters.';
    if (Object.keys(errors).length) return res.status(400).json({ error: 'Please fix the highlighted fields.', fields: errors });

    const duplicate = () =>
      res.status(409).json({ error: 'An account with this email already exists.', fields: { email: 'Already registered — try logging in.' } });
    if (await findByEmail(email)) return duplicate();

    const hash = await bcrypt.hash(password, 10);
    let result;
    try {
      [result] = await pool.query('INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)', [name, email, hash]);
    } catch (err) {
      if (err.code === 'ER_DUP_ENTRY') return duplicate(); // two sign-ups racing
      throw err;
    }
    const user = await findById(result.insertId);
    setAuthCookie(res, user);
    res.status(201).json({ user: publicUser(user) });
  });

  router.post('/login', async (req, res) => {
    const email = String(req.body?.email || '').trim().toLowerCase();
    const password = String(req.body?.password || '');
    const user = email ? await findByEmail(email) : null;
    const valid = user ? await bcrypt.compare(password, user.password_hash) : false;
    if (!valid) return res.status(401).json({ error: 'Incorrect email or password.' });
    setAuthCookie(res, user);
    res.json({ user: publicUser(user) });
  });

  router.post('/logout', (_req, res) => {
    clearAuthCookie(res);
    res.status(204).end();
  });

  router.get('/me', optionalAuth, async (req, res) => {
    const user = req.userId ? await findById(req.userId) : null;
    res.json({ user: user ? publicUser(user) : null });
  });

  return router;
}
