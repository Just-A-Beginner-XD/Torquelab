import { Router } from 'express';
import { optionalAuth } from '../middleware/auth.js';
import { recommend, ValidationError } from '../lib/recommend.js';

export function recommendationRoutes(pool, carRepo) {
  const router = Router();

  router.post('/', optionalAuth, async (req, res) => {
    let result;
    try {
      result = recommend(await carRepo.all(), req.body?.answers);
    } catch (err) {
      if (err instanceof ValidationError) return res.status(400).json({ error: err.message, details: err.details });
      throw err;
    }
    // Signed-in users get their answers remembered so the finder is pre-filled next time.
    if (req.userId) {
      await pool.query(
        'INSERT INTO user_preferences (user_id, answers) VALUES (?, ?) ON DUPLICATE KEY UPDATE answers = VALUES(answers)',
        [req.userId, JSON.stringify(result.answers)],
      );
    }
    res.json({ ...result, saved: Boolean(req.userId) });
  });

  return router;
}
