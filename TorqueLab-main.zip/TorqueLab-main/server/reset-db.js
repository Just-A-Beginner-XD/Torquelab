// Reloads the car catalogue from server/data into MySQL. User accounts are kept, but saved cars are cleared
// because car ids change (the demo account's saved cars are restored).
import { config } from './config.js';
import { initDatabase } from './db/index.js';
import { seedCatalogue, seedDemoData } from './db/seed.js';

const pool = await initDatabase(config, { attempts: 3 });
const { brands, cars } = await seedCatalogue(pool, { reset: true });
if (config.seedDemoData) await seedDemoData(pool, { restoreShortlist: true });
console.log(`Re-seeded ${cars} cars from ${brands} brands into ${config.db.host}/${config.db.database}.`);
await pool.end();
