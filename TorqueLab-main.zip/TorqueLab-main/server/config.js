import 'dotenv/config';

const PLACEHOLDER_SECRET = 'replace-with-a-long-random-string';
const bool = (value, fallback) =>
  value == null || value === '' ? fallback : ['1', 'true', 'yes', 'on'].includes(String(value).trim().toLowerCase());

// MySQL settings come either from DATABASE_URL (e.g. the "Service URI" shown by Aiven:
// mysql://user:pass@host:port/dbname?ssl-mode=REQUIRED) or from the individual DATABASE_* variables.
function databaseConfig(env) {
  const db = {
    host: env.DATABASE_HOST || 'localhost',
    port: Number(env.DATABASE_PORT) || 3306,
    user: env.DATABASE_USER || 'root',
    password: env.DATABASE_PASSWORD || '',
    database: env.DATABASE_NAME || 'torque_lab',
    ssl: bool(env.DATABASE_SSL, false),
    sslCa: env.DATABASE_SSL_CA || null,
  };
  if (env.DATABASE_URL) {
    const url = new URL(env.DATABASE_URL);
    db.host = url.hostname;
    db.port = Number(url.port) || 3306;
    db.user = decodeURIComponent(url.username);
    db.password = decodeURIComponent(url.password);
    db.database = url.pathname.replace(/^\//, '') || db.database;
    const sslMode = (url.searchParams.get('ssl-mode') || url.searchParams.get('sslmode') || '').toUpperCase();
    if (sslMode) db.ssl = sslMode !== 'DISABLED';
  }
  return db;
}

const jwtSecret = process.env.JWT_SECRET?.trim() || null;
if (jwtSecret === PLACEHOLDER_SECRET) {
  console.warn('[config] JWT_SECRET is still the .env.example placeholder. Change it before sharing this app.');
}

export const config = {
  isProduction: process.env.NODE_ENV === 'production',
  port: Number(process.env.PORT) || 4000,
  // When JWT_SECRET is not set, a random secret is generated once and stored in the database.
  jwtSecret,
  cookieSecure: bool(process.env.COOKIE_SECURE, false),
  seedDemoData: bool(process.env.SEED_DEMO_DATA, true),
  db: databaseConfig(process.env),
};
