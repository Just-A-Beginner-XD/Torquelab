import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import express from 'express';
import compression from 'compression';
import cookieParser from 'cookie-parser';
import { createCarRepository } from './lib/cars.js';
import { createNhtsaClient } from './lib/nhtsa.js';
import { authRoutes } from './routes/auth.js';
import { carRoutes } from './routes/cars.js';
import { clientErrorRoutes } from './routes/clientErrors.js';
import { meRoutes } from './routes/me.js';
import { recommendationRoutes } from './routes/recommendations.js';

const clientDist = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../dist');
const API_TIMEOUT_MS = 20_000;

export function createApp(pool) {
  const app = express();
  const carRepo = createCarRepository(pool);
  const nhtsa = createNhtsaClient(pool);

  app.disable('x-powered-by');
  app.use(compression()); // gzip responses: the JS bundle and car list shrink to about a third
  app.use(express.json({ limit: '50kb' }));
  app.use(cookieParser());

  // API responses are personal and change often: never cache them (browsers, Cloudflare or other proxies).
  // A request that hangs (e.g. on a dropped database connection) gets an error after 20 s instead of
  // leaving the page spinning forever.
  // Slow or failed API requests are logged, so they show up in `docker compose logs`.
  app.use('/api', (req, res, next) => {
    res.set('Cache-Control', 'no-store');
    const started = Date.now();
    const timer = setTimeout(() => {
      if (!res.headersSent) res.status(503).json({ error: 'The server took too long to respond. Please try again.' });
    }, API_TIMEOUT_MS);
    res.on('close', () => {
      clearTimeout(timer);
      const ms = Date.now() - started;
      if (res.statusCode >= 500 || ms > 5000) console.warn(`[api] ${req.method} ${req.originalUrl} -> ${res.statusCode} in ${ms} ms`);
    });
    next();
  });

  app.get('/api/health', async (_req, res) => {
    try {
      await pool.query('SELECT 1');
      res.json({ ok: true, database: 'up' });
    } catch {
      res.status(503).json({ ok: false, database: 'down' });
    }
  });
  app.use('/api/auth', authRoutes(pool));
  app.use('/api/cars', carRoutes(pool, carRepo, nhtsa));
  app.use('/api/me', meRoutes(pool, carRepo));
  app.use('/api/recommendations', recommendationRoutes(pool, carRepo));
  app.use('/api/client-errors', clientErrorRoutes(pool));
  app.use('/api', (_req, res) => res.status(404).json({ error: 'Not found.' }));

  // In production the built React app is served from the same server.
  if (fs.existsSync(clientDist)) {
    // Build files have a content hash in their name, so they can be cached for a year.
    app.use('/assets', express.static(path.join(clientDist, 'assets'), { immutable: true, maxAge: '1y' }));
    app.use(express.static(clientDist, { index: false, maxAge: '1h' }));
    app.use((req, res, next) => {
      if (req.method !== 'GET' && req.method !== 'HEAD') return next();
      // A missing file (e.g. an old bundle requested by a page cached before a redeploy) must be a real 404.
      // Answering with index.html would hand the browser HTML posing as JavaScript, and the page would stay blank.
      if (path.extname(req.path)) return res.status(404).type('text/plain').send('Not found');
      // The app shell is always revalidated, so every visit picks up the latest deploy.
      res.set('Cache-Control', 'no-cache');
      res.sendFile(path.join(clientDist, 'index.html'), { cacheControl: false });
    });
  }

  app.use((err, _req, res, next) => {
    if (res.headersSent) return next(err); // e.g. a request that already timed out
    if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'Invalid JSON body.' });
    console.error(err);
    res.status(500).json({ error: 'Something went wrong on our side.' });
  });

  return app;
}
