import jwt from 'jsonwebtoken';
import { config } from '../config.js';

export const AUTH_COOKIE = 'tl_token';
const TOKEN_TTL_SECONDS = 7 * 24 * 60 * 60;

export function setAuthCookie(res, user) {
  const token = jwt.sign({ sub: user.id }, config.jwtSecret, { expiresIn: TOKEN_TTL_SECONDS });
  res.cookie(AUTH_COOKIE, token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: config.cookieSecure,
    maxAge: TOKEN_TTL_SECONDS * 1000,
  });
}

export function clearAuthCookie(res) {
  res.clearCookie(AUTH_COOKIE, { httpOnly: true, sameSite: 'lax', secure: config.cookieSecure });
}

// Reads the auth cookie (if any) and sets req.userId. Never rejects the request.
export function optionalAuth(req, _res, next) {
  const token = req.cookies?.[AUTH_COOKIE];
  if (token) {
    try {
      req.userId = jwt.verify(token, config.jwtSecret).sub;
    } catch {
      req.userId = undefined;
    }
  }
  next();
}

export function requireAuth(req, res, next) {
  optionalAuth(req, res, () => {
    if (!req.userId) return res.status(401).json({ error: 'Please log in to continue.' });
    next();
  });
}
