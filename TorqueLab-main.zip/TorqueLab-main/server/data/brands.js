// Brands in the catalogue. `nhtsaMake` is the make name in the US NHTSA vehicle database (vPIC), used to show
// a brand's live global line-up on car pages. It is null for brands that do not sell cars in the US.
export const brands = [
  { name: 'Maruti Suzuki', country: 'India / Japan', nhtsaMake: 'Suzuki' },
  { name: 'Hyundai', country: 'South Korea', nhtsaMake: 'Hyundai' },
  { name: 'Volkswagen', country: 'Germany', nhtsaMake: 'Volkswagen' },
  { name: 'Tata', country: 'India', nhtsaMake: null },
  { name: 'Mahindra', country: 'India', nhtsaMake: null },
  { name: 'Honda', country: 'Japan', nhtsaMake: 'Honda' },
  { name: 'Toyota', country: 'Japan', nhtsaMake: 'Toyota' },
  { name: 'Kia', country: 'South Korea', nhtsaMake: 'Kia' },
  { name: 'Skoda', country: 'Czech Republic', nhtsaMake: null },
  { name: 'MG', country: 'United Kingdom / China', nhtsaMake: null },
  { name: 'Renault', country: 'France', nhtsaMake: null },
  { name: 'Nissan', country: 'Japan', nhtsaMake: 'Nissan' },
  { name: 'Citroen', country: 'France', nhtsaMake: null },
  { name: 'Jeep', country: 'United States', nhtsaMake: 'Jeep' },
  { name: 'BYD', country: 'China', nhtsaMake: null },
];
