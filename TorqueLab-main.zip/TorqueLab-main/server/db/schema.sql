-- Torque Lab database schema (MySQL 8+).
-- Applied automatically when the server starts; every statement is safe to run more than once.

CREATE TABLE IF NOT EXISTS brands (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(60)  NOT NULL UNIQUE,
  slug        VARCHAR(60)  NOT NULL UNIQUE,
  country     VARCHAR(60)  NOT NULL,
  nhtsa_make  VARCHAR(60)  NULL COMMENT 'Make name in the NHTSA vPIC API, if the brand sells in the US',
  created_at  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS cars (
  id                   INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  slug                 VARCHAR(80)   NOT NULL UNIQUE,
  brand_id             INT UNSIGNED  NOT NULL,
  model                VARCHAR(80)   NOT NULL,
  body_type            ENUM('hatchback','sedan','suv','muv') NOT NULL,
  price_min            DECIMAL(6,2)  NOT NULL COMMENT '₹ lakh, ex-showroom',
  price_max            DECIMAL(6,2)  NOT NULL,
  seating              JSON          NOT NULL COMMENT 'seat layouts offered, e.g. [6,7]',
  length_mm            SMALLINT UNSIGNED NOT NULL,
  ground_clearance_mm  SMALLINT UNSIGNED NOT NULL,
  boot_litres          SMALLINT UNSIGNED NOT NULL,
  ncap_stars           TINYINT UNSIGNED NULL,
  ncap_agency          VARCHAR(30)   NULL,
  airbags              TINYINT UNSIGNED NOT NULL,
  comfort              TINYINT UNSIGNED NOT NULL COMMENT 'Torque Lab rating 1-5',
  ownership            TINYINT UNSIGNED NOT NULL COMMENT 'Torque Lab rating 1-5',
  color                CHAR(7)       NOT NULL,
  summary              VARCHAR(255)  NOT NULL,
  created_at           TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at           TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_cars_brand FOREIGN KEY (brand_id) REFERENCES brands(id),
  INDEX idx_cars_body (body_type),
  INDEX idx_cars_price (price_min)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS car_engines (
  id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  car_id           INT UNSIGNED NOT NULL,
  position         TINYINT UNSIGNED NOT NULL,
  name             VARCHAR(80)  NOT NULL,
  fuel             ENUM('Petrol','Diesel','CNG','Hybrid','Electric') NOT NULL,
  displacement_cc  SMALLINT UNSIGNED NULL COMMENT 'NULL for electric motors',
  cylinders        TINYINT UNSIGNED NULL,
  power_bhp        SMALLINT UNSIGNED NOT NULL,
  torque_nm        SMALLINT UNSIGNED NOT NULL,
  battery_kwh      DECIMAL(5,2) NULL COMMENT 'electric only',
  CONSTRAINT fk_engines_car FOREIGN KEY (car_id) REFERENCES cars(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS car_fuel_options (
  car_id          INT UNSIGNED NOT NULL,
  fuel            ENUM('Petrol','Diesel','CNG','Hybrid','Electric') NOT NULL,
  starting_price  DECIMAL(6,2) NOT NULL COMMENT '₹ lakh, cheapest variant with this fuel',
  efficiency_min  DECIMAL(6,2) NOT NULL COMMENT 'km/l, km/kg (CNG) or km per charge (Electric)',
  efficiency_max  DECIMAL(6,2) NOT NULL,
  PRIMARY KEY (car_id, fuel),
  CONSTRAINT fk_fuels_car FOREIGN KEY (car_id) REFERENCES cars(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS car_transmissions (
  car_id        INT UNSIGNED NOT NULL,
  transmission  ENUM('Manual','AMT','CVT','DCT','Torque Converter','e-CVT','Single-speed') NOT NULL,
  PRIMARY KEY (car_id, transmission),
  CONSTRAINT fk_transmissions_car FOREIGN KEY (car_id) REFERENCES cars(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS car_highlights (
  id        INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  car_id    INT UNSIGNED NOT NULL,
  kind      ENUM('pro','con') NOT NULL,
  position  TINYINT UNSIGNED NOT NULL,
  text      VARCHAR(255) NOT NULL,
  CONSTRAINT fk_highlights_car FOREIGN KEY (car_id) REFERENCES cars(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS users (
  id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name           VARCHAR(100) NOT NULL,
  email          VARCHAR(191) NOT NULL UNIQUE,
  password_hash  VARCHAR(100) NOT NULL,
  created_at     TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS user_preferences (
  user_id     INT UNSIGNED PRIMARY KEY,
  answers     JSON      NOT NULL COMMENT 'last Car Finder answers',
  updated_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_prefs_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS shortlists (
  user_id     INT UNSIGNED NOT NULL,
  car_id      INT UNSIGNED NOT NULL,
  created_at  TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (user_id, car_id),
  CONSTRAINT fk_shortlists_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_shortlists_car FOREIGN KEY (car_id) REFERENCES cars(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS api_cache (
  cache_key   VARCHAR(191) PRIMARY KEY,
  payload     JSON      NOT NULL,
  fetched_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS app_settings (
  name   VARCHAR(64)  PRIMARY KEY,
  value  VARCHAR(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS client_errors (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  created_at  TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  kind        VARCHAR(30)   NOT NULL COMMENT 'no-render, asset-error, render, js-error, promise, api-failed, api-slow',
  message     VARCHAR(1000) NOT NULL,
  page_url    VARCHAR(500)  NOT NULL,
  user_agent  VARCHAR(400)  NOT NULL,
  detail      JSON          NULL,
  INDEX idx_client_errors_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
