import bcrypt from 'bcryptjs';
import { brands } from '../data/brands.js';
import { cars } from '../data/cars.js';
import { FUEL_PREMIUM } from '../lib/cars.js';

export const DEMO_USER = { name: 'Demo Driver', email: 'demo@torquelab.dev', password: 'DemoPass123' };
const DEMO_SHORTLIST = ['tata-nexon', 'maruti-suzuki-brezza', 'hyundai-creta', 'kia-syros'];
const DEMO_ANSWERS = {
  budget: 12,
  familySize: 4,
  newDriver: false,
  dailyKm: 35,
  conditions: 'mixed',
  mileagePref: '15-20',
  fuel: 'any',
  transmission: 'automatic',
  bodyType: 'any',
  priorities: ['safety', 'comfort'],
};

const slugify = (s) => s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
const round2 = (n) => Math.round(n * 100) / 100;

// Starting price per fuel. The listed base price belongs to petrol when offered, otherwise to the first fuel;
// other fuels use the car's explicit `fuelFrom` value or a typical premium over the base price.
function startingPrices(car) {
  const fuels = Object.keys(car.mileage);
  const baseFuel = fuels.includes('Petrol') ? 'Petrol' : fuels[0];
  return Object.fromEntries(
    fuels.map((fuel) => [
      fuel,
      car.fuelFrom?.[fuel] ?? (fuel === baseFuel ? car.price[0] : Math.min(round2(car.price[0] + FUEL_PREMIUM[fuel]), car.price[1])),
    ]),
  );
}

// Inserts every brand and car from server/data in a single transaction, using bulk inserts so it is quick
// even against a remote database. With { reset: true } the existing catalogue is removed first
// (which also clears users' saved cars, since those point at car ids).
export async function seedCatalogue(pool, { reset = false } = {}) {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    if (reset) {
      await conn.query('DELETE FROM cars');
      await conn.query('DELETE FROM brands');
    }

    await conn.query('INSERT INTO brands (name, slug, country, nhtsa_make) VALUES ?', [
      brands.map((b) => [b.name, slugify(b.name), b.country, b.nhtsaMake]),
    ]);
    const [brandRows] = await conn.query('SELECT id, name FROM brands');
    const brandId = new Map(brandRows.map((r) => [r.name, r.id]));

    await conn.query(
      `INSERT INTO cars (slug, brand_id, model, body_type, price_min, price_max, seating, length_mm,
        ground_clearance_mm, boot_litres, ncap_stars, ncap_agency, airbags, comfort, ownership, color, summary)
       VALUES ?`,
      [
        cars.map((c) => [
          c.slug, brandId.get(c.brand), c.model, c.bodyType, c.price[0], c.price[1], JSON.stringify(c.seating),
          c.lengthMm, c.groundClearanceMm, c.bootLitres, c.safety.stars, c.safety.agency, c.safety.airbags,
          c.comfort, c.ownership, c.color, c.summary,
        ]),
      ],
    );
    const [carRows] = await conn.query('SELECT id, slug FROM cars');
    const carId = new Map(carRows.map((r) => [r.slug, r.id]));

    const engines = [];
    const fuels = [];
    const transmissions = [];
    const highlights = [];
    for (const c of cars) {
      const id = carId.get(c.slug);
      c.engines.forEach((e, i) =>
        engines.push([id, i, e.name, e.fuel, e.cc || null, e.cylinders || null, e.powerBhp, e.torqueNm, e.batteryKwh ?? null]),
      );
      const prices = startingPrices(c);
      for (const [fuel, [min, max]] of Object.entries(c.mileage)) fuels.push([id, fuel, prices[fuel], min, max]);
      for (const t of c.transmissions) transmissions.push([id, t]);
      c.pros.forEach((text, i) => highlights.push([id, 'pro', i, text]));
      c.cons.forEach((text, i) => highlights.push([id, 'con', i, text]));
    }
    await conn.query(
      'INSERT INTO car_engines (car_id, position, name, fuel, displacement_cc, cylinders, power_bhp, torque_nm, battery_kwh) VALUES ?',
      [engines],
    );
    await conn.query('INSERT INTO car_fuel_options (car_id, fuel, starting_price, efficiency_min, efficiency_max) VALUES ?', [fuels]);
    await conn.query('INSERT INTO car_transmissions (car_id, transmission) VALUES ?', [transmissions]);
    await conn.query('INSERT INTO car_highlights (car_id, kind, position, text) VALUES ?', [highlights]);

    await conn.commit();
    return { brands: brands.length, cars: cars.length };
  } catch (err) {
    await conn.rollback();
    throw err;
  } finally {
    conn.release();
  }
}

// Creates a demo account with a few saved cars and Car Finder answers, so the site has something to show
// straight away. Does nothing if the account already exists, unless restoreShortlist is set (used after a reset).
export async function seedDemoData(pool, { restoreShortlist = false } = {}) {
  const [existing] = await pool.query('SELECT id FROM users WHERE email = ?', [DEMO_USER.email]);
  let userId = existing[0]?.id;
  const created = !userId;
  if (created) {
    const hash = await bcrypt.hash(DEMO_USER.password, 10);
    const [res] = await pool.query('INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)', [
      DEMO_USER.name,
      DEMO_USER.email,
      hash,
    ]);
    userId = res.insertId;
    await pool.query('INSERT INTO user_preferences (user_id, answers) VALUES (?, ?)', [userId, JSON.stringify(DEMO_ANSWERS)]);
  }
  if (created || restoreShortlist) {
    await pool.query('INSERT IGNORE INTO shortlists (user_id, car_id) SELECT ?, id FROM cars WHERE slug IN (?)', [
      userId,
      DEMO_SHORTLIST,
    ]);
  }
  return created;
}
