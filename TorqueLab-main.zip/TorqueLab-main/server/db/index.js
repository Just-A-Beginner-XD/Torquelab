import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import mysql from 'mysql2/promise';
import { seedCatalogue, seedDemoData } from './seed.js';

const SCHEMA_FILE = path.join(path.dirname(fileURLToPath(import.meta.url)), 'schema.sql');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function poolOptions(db, { withDatabase = true } = {}) {
  let ssl;
  if (db.ssl) {
    // With a CA file the server certificate is verified; without one the link is still encrypted.
    ssl = db.sslCa ? { ca: fs.readFileSync(db.sslCa, 'utf8') } : { rejectUnauthorized: false };
  }
  return {
    host: db.host,
    port: db.port,
    user: db.user,
    password: db.password,
    database: withDatabase ? db.database : undefined,
    ssl,
    charset: 'utf8mb4',
    timezone: 'Z',
    decimalNumbers: true, // return DECIMAL columns as numbers
    connectTimeout: 10000,
    waitForConnections: true,
    connectionLimit: 10,
    // Close connections that sit idle for a minute instead of reusing them later: firewalls and NAT gateways
    // between the app and a cloud database often drop idle connections silently, and a query sent on such a
    // connection hangs instead of failing.
    maxIdle: 3,
    idleTimeout: 60_000,
    enableKeepAlive: true,
    keepAliveInitialDelay: 30_000,
  };
}

// Turns low-level driver errors into advice a person can act on.
export function describeDbError(err, db) {
  const where = `${db.host}:${db.port}`;
  switch (err?.code) {
    case 'ENOTFOUND':
    case 'EAI_AGAIN':
      return `Host "${db.host}" could not be found. Check DATABASE_HOST, and if it is a cloud database make sure the service is running.`;
    case 'ECONNREFUSED':
      return `Nothing is accepting connections at ${where}. Is MySQL running, and is DATABASE_PORT correct?`;
    case 'ETIMEDOUT':
    case 'ECONNRESET':
      return (
        `The connection to ${where} timed out or was dropped. Check DATABASE_PORT (cloud databases such as Aiven ` +
        'use a custom port, not 3306), firewalls, any IP allow-list on the database, and whether it requires SSL (DATABASE_SSL=true).'
      );
    case 'ER_ACCESS_DENIED_ERROR':
      return `MySQL rejected the login for user "${db.user}". Check DATABASE_USER and DATABASE_PASSWORD.`;
    case 'ER_BAD_DB_ERROR':
      return `Database "${db.database}" does not exist and this user cannot create it. Create it or change DATABASE_NAME.`;
    case 'HANDSHAKE_NO_SSL_SUPPORT':
      return `The server at ${where} does not support SSL. Set DATABASE_SSL=false.`;
    default:
      return `${err?.code || 'Error'}: ${err?.message}`;
  }
}

async function openPool(db) {
  let pool = mysql.createPool(poolOptions(db));
  try {
    await pool.query('SELECT 1');
    return pool;
  } catch (err) {
    await pool.end().catch(() => {});
    if (err.code !== 'ER_BAD_DB_ERROR') throw err;
    // The server is reachable but the database is missing: create it if the user is allowed to.
    const admin = await mysql.createConnection(poolOptions(db, { withDatabase: false }));
    try {
      const name = db.database.replace(/`/g, '');
      await admin.query(`CREATE DATABASE IF NOT EXISTS \`${name}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`);
    } finally {
      await admin.end();
    }
    pool = mysql.createPool(poolOptions(db));
    await pool.query('SELECT 1');
    return pool;
  }
}

// Connects, retrying for a while so the app can start before the database is ready (e.g. in Docker).
export async function connect(db, { attempts = 10, delayMs = 3000 } = {}) {
  let lastError;
  for (let attempt = 1; attempt <= attempts; attempt++) {
    try {
      return await openPool(db);
    } catch (err) {
      lastError = err;
      console.warn(`[db] Connection attempt ${attempt}/${attempts} failed. ${describeDbError(err, db)}`);
      if (err.code === 'ER_ACCESS_DENIED_ERROR' || attempt === attempts) break;
      await sleep(delayMs);
    }
  }
  const error = new Error(`Could not connect to MySQL at ${db.host}:${db.port}. ${describeDbError(lastError, db)}`);
  error.cause = lastError;
  throw error;
}

// Creates any missing tables. Every statement in schema.sql uses CREATE TABLE IF NOT EXISTS.
export async function applySchema(pool) {
  const statements = fs
    .readFileSync(SCHEMA_FILE, 'utf8')
    .replace(/^\s*--.*$/gm, '')
    .split(/;\s*(?:\n|$)/)
    .map((s) => s.trim())
    .filter(Boolean);
  for (const statement of statements) await pool.query(statement);
}

async function getOrCreateSetting(pool, name, create) {
  await pool.query('INSERT IGNORE INTO app_settings (name, value) VALUES (?, ?)', [name, create()]);
  const [rows] = await pool.query('SELECT value FROM app_settings WHERE name = ?', [name]);
  return rows[0].value;
}

// Connects, creates tables, seeds sample data on first run and resolves the JWT secret.
export async function initDatabase(config, options) {
  const pool = await connect(config.db, options);
  await applySchema(pool);

  const [[{ count }]] = await pool.query('SELECT COUNT(*) AS count FROM cars');
  if (count === 0) {
    const seeded = await seedCatalogue(pool);
    console.log(`[db] Seeded ${seeded.cars} cars from ${seeded.brands} brands.`);
  }
  if (config.seedDemoData && (await seedDemoData(pool))) {
    console.log('[db] Created the demo account (demo@torquelab.dev).');
  }
  if (!config.jwtSecret) {
    config.jwtSecret = await getOrCreateSetting(pool, 'jwt_secret', () => crypto.randomBytes(32).toString('hex'));
  }
  return pool;
}
