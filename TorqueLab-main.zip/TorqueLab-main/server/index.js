import { config } from './config.js';
import { initDatabase } from './db/index.js';
import { createApp } from './app.js';

// Log anything that would otherwise crash the server silently. On an uncaught exception the process exits
// so Docker restarts it in a clean state; the log line says why.
process.on('unhandledRejection', (reason) => console.error('[process] Unhandled promise rejection:', reason));
process.on('uncaughtException', (err) => {
  console.error('[process] Uncaught exception, exiting:', err);
  process.exit(1);
});

let pool;
try {
  pool = await initDatabase(config);
} catch (err) {
  console.error(`\n[db] ${err.message}\n`);
  process.exit(1);
}

const app = createApp(pool);
const server = app.listen(config.port, () => {
  console.log(`Torque Lab listening on http://localhost:${config.port} (MySQL ${config.db.host}:${config.db.port}/${config.db.database})`);
});

const shutdown = () => {
  server.close(async () => {
    await pool.end().catch(() => {});
    process.exit(0);
  });
};
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
