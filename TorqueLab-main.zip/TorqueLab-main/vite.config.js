import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig(({ mode }) => {
  // Read PORT from the project-root .env so the dev proxy targets the same port as the API.
  const env = loadEnv(mode, process.cwd(), '');
  const apiPort = env.PORT || 4000;

  return {
    root: 'client',
    plugins: [react()],
    build: {
      outDir: '../dist',
      emptyOutDir: true,
    },
    server: {
      port: 5173,
      proxy: {
        '/api': `http://localhost:${apiPort}`,
      },
    },
  };
});
